import os
import sys
import json
import asyncio
import pygame

# ------------------------------------------------------------------
# Make sure the working directory is always the folder containing
# this main.py on desktop. On the web (emscripten), os.chdir isn't
# supported and the working directory is handled by Pygbag.
# ------------------------------------------------------------------
if sys.platform != "emscripten":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

from scenes.start import StartScene


# ------------------------------------------------------------------
# Config
# ------------------------------------------------------------------
RENDER_W, RENDER_H = 640, 480
WINDOW_W, WINDOW_H = 960, 720

TITLE = "Our Home"
SAVE_FILE = "save.json"

# Transition timings (seconds)
FADE_OUT_TIME = 0.28
HOLD_TIME     = 1.0
FADE_IN_TIME  = 0.28

# Fade colour — change to (0, 0, 0) for a black fade
FADE_COLOR = (255, 255, 255)


# ------------------------------------------------------------------
# Save / load
# ------------------------------------------------------------------
def load_progress():
    if os.path.exists(SAVE_FILE):
        try:
            with open(SAVE_FILE, "r") as f:
                data = json.load(f)
                if "completed" not in data:
                    data["completed"] = []
                if "intro_seen" not in data:
                    data["intro_seen"] = False
                if "returned_to_title" not in data:
                    data["returned_to_title"] = False
                return data
        except (json.JSONDecodeError, OSError):
            pass
    return {"completed": [], "intro_seen": False, "returned_to_title": False}


def save_progress(progress):
    try:
        with open(SAVE_FILE, "w") as f:
            json.dump(progress, f)
    except OSError:
        pass


# ------------------------------------------------------------------
# Scene manager with built-in fade transitions
# ------------------------------------------------------------------
class SceneManager:
    def __init__(self, progress):
        self.progress = progress
        self.scene = StartScene(self)
        self.running = True

        # Transition state
        # phase: "none" / "out" / "hold" / "in"
        self.phase = "none"
        self.timer = 0.0
        self.pending_scene = None

    # ------------------------------------------------------------------
    def go_to(self, scene_or_factory, instant=False):
        """Begin a fade transition to a new scene.

        Pass either a Scene instance directly, or a callable (lambda /
        function) that constructs the scene. Using a callable defers
        the scene's __init__ until the "hold" phase, so any slow
        scene setup doesn't stall the fade.
        """
        if self.phase != "none":
            return

        if instant:
            if callable(scene_or_factory):
                self.scene = scene_or_factory()
            else:
                self.scene = scene_or_factory
            self.pending_scene = None
            self.phase = "none"
            self.timer = 0.0
            return

        self.pending_scene = scene_or_factory
        self.phase = "out"
        self.timer = 0.0

    def quit(self):
        self.running = False

    # ------------------------------------------------------------------
    def update(self, dt):
        if self.phase == "out":
            self.timer += dt
            if self.timer >= FADE_OUT_TIME:
                self.phase = "hold"
                self.timer = 0.0

        elif self.phase == "hold":
            self.timer += dt
            if self.timer >= HOLD_TIME:
                if self.pending_scene is not None:
                    if callable(self.pending_scene):
                        self.scene = self.pending_scene()
                    else:
                        self.scene = self.pending_scene
                    self.pending_scene = None
                self.phase = "in"
                self.timer = 0.0

        elif self.phase == "in":
            self.timer += dt
            if self.timer >= FADE_IN_TIME:
                self.phase = "none"
                self.timer = 0.0

        if self.phase == "none":
            self.scene.update(dt)

    # ------------------------------------------------------------------
    def handle_event(self, event):
        if self.phase != "none":
            return
        self.scene.handle_event(event)

    # ------------------------------------------------------------------
    def draw(self, render_surface):
        self.scene.draw(render_surface)

        alpha = 0
        if self.phase == "out":
            alpha = int(255 * min(self.timer / FADE_OUT_TIME, 1.0))
        elif self.phase == "hold":
            alpha = 255
        elif self.phase == "in":
            alpha = int(255 * (1 - min(self.timer / FADE_IN_TIME, 1.0)))

        if alpha > 0:
            overlay = pygame.Surface((RENDER_W, RENDER_H))
            overlay.fill(FADE_COLOR)
            overlay.set_alpha(alpha)
            render_surface.blit(overlay, (0, 0))

            if self.phase == "hold":
                font = pygame.font.SysFont("arial", 18, bold=True)
                pulse = 0.5 + 0.5 * pygame.math.Vector2(1, 0).rotate(
                    self.timer * 900
                ).x

                if sum(FADE_COLOR) > 384:
                    shade = int(60 + 60 * pulse)
                    txt_color = (shade, shade, shade)
                else:
                    shade = int(140 + 80 * pulse)
                    txt_color = (shade, shade, shade)

                text = font.render("Loading…", True, txt_color)
                render_surface.blit(
                    text,
                    (RENDER_W//2 - text.get_width()//2,
                     RENDER_H//2 - text.get_height()//2)
                )


# ------------------------------------------------------------------
# Main game loop (async so it also works with Pygbag on the web)
# ------------------------------------------------------------------
async def main():
    pygame.init()
    pygame.display.set_caption(TITLE)

    screen = pygame.display.set_mode((WINDOW_W, WINDOW_H))
    render_surface = pygame.Surface((RENDER_W, RENDER_H))

    clock = pygame.time.Clock()

    progress = load_progress()
    manager = SceneManager(progress)

    while manager.running:
        dt = clock.tick(60) / 1000.0
        dt = min(dt, 0.1)   # cap frame time so fades always play out

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                manager.quit()
            else:
                if event.type in (pygame.MOUSEBUTTONDOWN,
                                  pygame.MOUSEBUTTONUP,
                                  pygame.MOUSEMOTION):
                    event = _translate_mouse_event(event)
                manager.handle_event(event)

        manager.update(dt)
        manager.draw(render_surface)

        pygame.transform.scale(render_surface, (WINDOW_W, WINDOW_H), screen)
        pygame.display.flip()

        await asyncio.sleep(0)

    save_progress(manager.progress)
    # pygame.quit() shuts down the WASM runtime on web — skip it there
    if sys.platform != "emscripten":
        pygame.quit()


def _translate_mouse_event(event):
    sx = RENDER_W / WINDOW_W
    sy = RENDER_H / WINDOW_H
    if hasattr(event, "pos") and event.pos:
        new_pos = (int(event.pos[0] * sx), int(event.pos[1] * sy))
        attrs = dict(event.dict)
        attrs["pos"] = new_pos
        return pygame.event.Event(event.type, attrs)
    return event


# ------------------------------------------------------------------
# Entry point
# ------------------------------------------------------------------
if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
    # sys.exit() also breaks the browser runtime — guard it
    if sys.platform != "emscripten":
        sys.exit()
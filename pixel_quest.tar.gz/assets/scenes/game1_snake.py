import os
import random
import pygame
from scenes.base_scene import Scene

ASSETS = "assets"
def asset(*parts):
    return os.path.join(ASSETS, *parts)


def load_image(path, size, fallback_color=None):
    if os.path.exists(path):
        img = pygame.image.load(path).convert_alpha()
        return pygame.transform.scale(img, size)
    surf = pygame.Surface(size, pygame.SRCALPHA)
    if fallback_color:
        surf.fill(fallback_color)
    return surf


def load_font(name, size):
    path = os.path.join(ASSETS, "fonts", name)
    if os.path.exists(path):
        return pygame.font.Font(path, size)
    if name.endswith(".otf"):
        alt = name[:-4] + ".ttf"
    elif name.endswith(".ttf"):
        alt = name[:-4] + ".otf"
    else:
        alt = None
    if alt:
        alt_path = os.path.join(ASSETS, "fonts", alt)
        if os.path.exists(alt_path):
            return pygame.font.Font(alt_path, size)
    return pygame.font.SysFont("arial", size, bold=True)


FONT_FILE     = "windraw.otf"
UI_FONT       = "FatPix-SVG.otf"
TUTORIAL_FONT = "DaintyCute.otf"

UI_MAIN   = (255, 215, 140)
UI_SHADOW = (110, 55, 30)
UI_ORANGE = (255, 155, 120)

# Sentence with 20 chars + 1 heart = 21 pickups
SENTENCE = "I Love You Christine"

SENTENCE_POSITIONS = [
    (2, 3), (3, 3), (4, 3), (5, 3), (6, 3), (7, 3),
    (8, 3), (9, 3), (10, 3), (11, 3), (12, 3),
    (2, 4), (3, 4), (4, 4), (5, 4), (6, 4), (7, 4),
    (8, 4), (9, 4), (10, 4),
]

HEART_POSITION = (11, 4)
TARGET_SCORE = len(SENTENCE) + 1


class SnakeScene(Scene):
    KEY = "snake"

    GRID_COLS = 14
    GRID_ROWS = 9
    CELL = 24
    ORIGIN = (144, 167)

    def __init__(self, manager):
        super().__init__(manager)
        self.screen_w, self.screen_h = 640, 480

        # Windraw for letters / final message
        self.font        = load_font(FONT_FILE, 18)
        self.letter_font = load_font(FONT_FILE, 22)
        self.reveal_font = load_font(FONT_FILE, 26)

        # Arial fallback for characters Windraw doesn't have (hyphen)
        self.hyphen_font = pygame.font.SysFont("arial", 22, bold=True)

        # FatPix UI
        self.ui_font     = load_font(UI_FONT, 24)
        self.ui_medium   = load_font(UI_FONT, 20)
        self.ui_large    = load_font(UI_FONT, 34)

        # DaintyCute tutorial
        self.tut_font    = load_font(TUTORIAL_FONT, 26)
        self.tut_body    = load_font(TUTORIAL_FONT, 20)
        self.tut_small   = load_font(TUTORIAL_FONT, 18)

        # Background
        self.bg = load_image(
            asset("sprites", "snake_bg.png"),
            (self.screen_w, self.screen_h),
            fallback_color=(20, 15, 35)
        )

        # Ink pot sprite
        self.ink_pot = load_image(
            asset("sprites", "ink_pot.png"),
            (self.CELL - 4, self.CELL - 4),
            fallback_color=(50, 40, 80)
        )
        self.ink_pot_has_sprite = os.path.exists(
            asset("sprites", "ink_pot.png")
        )

        # Heart sprite
        self.heart = load_image(
            asset("sprites", "heart.png"),
            (self.CELL - 4, self.CELL - 4),
            fallback_color=(200, 60, 60)
        )
        self.heart_has_sprite = os.path.exists(
            asset("sprites", "heart.png")
        )

        self._tutorial_shown = False
        self.reset()

    # ------------------------------------------------------------------
    def reset(self):
        self.snake = [(2, 3)]
        self.direction = (1, 0)
        self.queued_dir = (1, 0)
        self.queued_dir2 = None
        self.apple = self._new_apple()
        self.score = 1
        self.move_timer = 0.0
        self.move_interval = 0.18
        self.game_over = False
        self.won = False
        self.started = self._tutorial_shown

    def _new_apple(self):
        margin = 1
        while True:
            pos = (random.randint(margin, self.GRID_COLS - 1 - margin),
                   random.randint(margin, self.GRID_ROWS - 1 - margin))
            if pos not in self.snake:
                return pos

    # ------------------------------------------------------------------
    def _admin_combo(self):
        keys = pygame.key.get_pressed()
        return (keys[pygame.K_LCTRL] and
                keys[pygame.K_LSHIFT] and
                keys[pygame.K_k])

    # ------------------------------------------------------------------
    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if (self.won or self.game_over) and event.button == 1:
                self._leave()
                return
            if (self.won or self.game_over) and event.button == 3:
                self.reset()
                return

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_k and self._admin_combo():
                # Admin: mark complete and show the win screen
                self._complete()
                self.score = TARGET_SCORE
                self.won = True
                self.game_over = False
                return

            if event.key == pygame.K_ESCAPE:
                self._leave()
            elif event.key == pygame.K_r and (self.game_over or self.won):
                self.reset()
            elif not self.started and event.key in (
                pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT
            ):
                self.started = True
                self._tutorial_shown = True
            elif self.started and not self.game_over and not self.won:
                new_dir = None
                if event.key == pygame.K_UP    and self.direction != (0, 1):  new_dir = (0, -1)
                if event.key == pygame.K_DOWN  and self.direction != (0, -1): new_dir = (0, 1)
                if event.key == pygame.K_LEFT  and self.direction != (1, 0):  new_dir = (-1, 0)
                if event.key == pygame.K_RIGHT and self.direction != (-1, 0): new_dir = (1, 0)

                if new_dir and new_dir != self.direction:
                    if self.queued_dir == self.direction:
                        self.queued_dir = new_dir
                    elif self.queued_dir2 is None:
                        self.queued_dir2 = new_dir

    # ------------------------------------------------------------------
    def update(self, dt):
        if self.game_over or self.won or not self.started:
            return

        self.move_timer += dt
        if self.move_timer < self.move_interval:
            return
        self.move_timer = 0.0

        self.direction = self.queued_dir
        if self.queued_dir2 is not None:
            self.queued_dir = self.queued_dir2
            self.queued_dir2 = None

        head = self.snake[0]
        nx = head[0] + self.direction[0]
        ny = head[1] + self.direction[1]

        if nx < 0 or ny < 0 or nx >= self.GRID_COLS or ny >= self.GRID_ROWS:
            self.game_over = True
            return

        if (nx, ny) in self.snake[:-1]:
            self.game_over = True
            return

        new_head = (nx, ny)
        self.snake.insert(0, new_head)

        if new_head == self.apple:
            self.score += 1
            if self.score >= TARGET_SCORE:
                self.won = True
                self._complete()
                return
            self.apple = self._new_apple()
        else:
            self.snake.pop()

    # ------------------------------------------------------------------
    def _complete(self):
        if self.KEY not in self.manager.progress["completed"]:
            self.manager.progress["completed"].append(self.KEY)

    def _leave(self):
        from scenes.hub import HubScene
        self.manager.go_to(lambda: HubScene(self.manager))

    def _letter_at(self, index):
        """Character for a snake segment. Spaces shown as '-' during play."""
        if 0 <= index < len(SENTENCE):
            ch = SENTENCE[index]
            if ch == " ":
                return "-"
            return ch
        return ""

    def _is_heart_segment(self, index):
        return index == len(SENTENCE)

    # ------------------------------------------------------------------
    def _draw_ui_text(self, screen, font, text, x, y,
                      main=UI_MAIN, shadow=UI_SHADOW):
        shadow_surf = font.render(text, False, shadow)
        main_surf   = font.render(text, False, main)
        screen.blit(shadow_surf, (x + 2, y + 2))
        screen.blit(main_surf,   (x, y))
        return main_surf.get_width()

    def _draw_ui_text_center(self, screen, font, text, cx, y,
                             main=UI_MAIN, shadow=UI_SHADOW):
        main_surf = font.render(text, False, main)
        shadow_surf = font.render(text, False, shadow)
        x = cx - main_surf.get_width() // 2
        screen.blit(shadow_surf, (x + 2, y + 2))
        screen.blit(main_surf,   (x,     y))

    # ------------------------------------------------------------------
    def draw(self, screen):
        screen.blit(self.bg, (0, 0))

        # Top-left title + counter
        ui_x = 20
        ui_y = 16
        snake_label_w = self._draw_ui_text(
            screen, self.ui_font, "Snake", ui_x, ui_y
        )
        counter_x = ui_x + snake_label_w + 22
        self._draw_ui_text(
            screen, self.ui_font,
            f"{self.score}/{TARGET_SCORE}",
            counter_x, ui_y
        )

        # Playfield content
        if not self.won:
            ax = self.ORIGIN[0] + self.apple[0] * self.CELL
            ay = self.ORIGIN[1] + self.apple[1] * self.CELL
            if self.ink_pot_has_sprite:
                screen.blit(self.ink_pot, (ax + 2, ay + 2))
            else:
                pygame.draw.rect(screen, (50, 40, 90),
                                 (ax + 4, ay + 4,
                                  self.CELL - 8, self.CELL - 8),
                                 border_radius=5)

            for i, (x, y) in enumerate(self.snake):
                px = self.ORIGIN[0] + x * self.CELL
                py = self.ORIGIN[1] + y * self.CELL

                if self._is_heart_segment(i):
                    if self.heart_has_sprite:
                        screen.blit(self.heart, (px + 2, py + 2))
                    else:
                        pygame.draw.circle(screen, (220, 60, 60),
                                           (px + self.CELL // 2,
                                            py + self.CELL // 2),
                                           self.CELL // 2 - 2)
                else:
                    ch = self._letter_at(i)
                    if not ch:
                        continue
                    # Arial for hyphens, Windraw for everything else
                    if ch == "-":
                        render_font = self.hyphen_font
                        # Nudge the hyphen slightly down so it centers visually
                        y_offset = 3
                    else:
                        render_font = self.letter_font
                        y_offset = 0

                    shadow = render_font.render(ch, True, (60, 25, 20))
                    main   = render_font.render(ch, True, (140, 60, 50))
                    cx = px + self.CELL // 2
                    cy = py + self.CELL // 2 + y_offset
                    screen.blit(shadow, (cx - shadow.get_width() // 2 + 1,
                                         cy - shadow.get_height() // 2 + 1))
                    screen.blit(main,   (cx - main.get_width() // 2,
                                         cy - main.get_height() // 2))

        if not self.started and not (self.won or self.game_over):
            self._draw_intro(screen)

        if self.won:
            self._draw_final_message(screen)
            self._draw_ui_text_center(
                screen, self.ui_medium,
                "Click or press ESC to return to the hub",
                320, 400
            )
            self._draw_ui_text_center(
                screen, self.ui_medium,
                "Press R to replay",
                320, 430
            )
        elif self.game_over:
            self._draw_ui_text_center(
                screen, self.ui_large, "GAME OVER",
                320, 195, main=UI_ORANGE, shadow=UI_SHADOW
            )
            self._draw_ui_text_center(
                screen, self.ui_medium,
                "Click or press ESC to return to the hub",
                320, 255
            )
            self._draw_ui_text_center(
                screen, self.ui_medium,
                "Press R to retry",
                320, 285
            )

    # ------------------------------------------------------------------
    def _draw_final_message(self, screen):
        # Letters in SENTENCE (spaces stay spaces in the final message)
        for index, ch in enumerate(SENTENCE):
            if ch == " ":
                continue
            col, row = SENTENCE_POSITIONS[index]
            px = self.ORIGIN[0] + col * self.CELL
            py = self.ORIGIN[1] + row * self.CELL

            shadow = self.reveal_font.render(ch, True, (60, 25, 20))
            main   = self.reveal_font.render(ch, True, (140, 60, 50))
            cx = px + self.CELL // 2
            cy = py + self.CELL // 2
            screen.blit(shadow, (cx - shadow.get_width() // 2 + 1,
                                 cy - shadow.get_height() // 2 + 1))
            screen.blit(main,   (cx - main.get_width() // 2,
                                 cy - main.get_height() // 2))

        # Heart after Christine
        col, row = HEART_POSITION
        px = self.ORIGIN[0] + col * self.CELL
        py = self.ORIGIN[1] + row * self.CELL
        if self.heart_has_sprite:
            screen.blit(self.heart, (px + 2, py + 2))
        else:
            pygame.draw.circle(screen, (220, 60, 60),
                               (px + self.CELL // 2, py + self.CELL // 2),
                               self.CELL // 2 - 2)

    # ------------------------------------------------------------------
    def _draw_intro(self, screen):
        overlay = pygame.Surface((640, 480), pygame.SRCALPHA)
        overlay.fill((60, 30, 20, 140))
        screen.blit(overlay, (0, 0))

        panel = pygame.Rect(100, 90, 440, 320)
        pygame.draw.rect(screen, (245, 230, 200), panel, border_radius=18)
        pygame.draw.rect(screen, (150, 90, 60), panel, 4, border_radius=18)

        title = self.tut_font.render("HOW TO PLAY", True, (150, 70, 50))
        screen.blit(title, (320 - title.get_width() // 2, 110))

        cx, cy = 320, 195
        gap = 34
        arrow_color = (90, 180, 120)

        pygame.draw.polygon(screen, arrow_color, [
            (cx,        cy - gap - 14),
            (cx - 16,   cy - gap + 6),
            (cx + 16,   cy - gap + 6),
        ])
        pygame.draw.polygon(screen, arrow_color, [
            (cx,        cy + gap + 14),
            (cx - 16,   cy + gap - 6),
            (cx + 16,   cy + gap - 6),
        ])
        pygame.draw.polygon(screen, arrow_color, [
            (cx - gap - 14, cy),
            (cx - gap + 6,  cy - 16),
            (cx - gap + 6,  cy + 16),
        ])
        pygame.draw.polygon(screen, arrow_color, [
            (cx + gap + 14, cy),
            (cx + gap - 6,  cy - 16),
            (cx + gap - 6,  cy + 16),
        ])

        lines = [
            "Use the arrow keys to steer the snake.",
            "Collect ink pots to spell a message.",
            "Do not hit the walls or yourself.",
            "",
            "Press any arrow key to begin",
        ]
        y = 268
        for line in lines:
            if line == "":
                y += 8
                continue
            if "begin" in line:
                color = (180, 80, 60)
                surf = self.tut_small.render(line, True, color)
                screen.blit(surf, (320 - surf.get_width() // 2, y + 6))
                y += 30
            else:
                color = (90, 55, 40)
                surf = self.tut_body.render(line, True, color)
                screen.blit(surf, (320 - surf.get_width() // 2, y))
                y += 30
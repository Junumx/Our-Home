import os
import pygame
from scenes.base_scene import Scene

ASSETS = "assets"
def asset(*parts):
    return os.path.join(ASSETS, *parts)


def load_image_native(path, fallback_color=None):
    if os.path.exists(path):
        return pygame.image.load(path).convert_alpha()
    surf = pygame.Surface((300, 400), pygame.SRCALPHA)
    if fallback_color:
        surf.fill(fallback_color)
    return surf


def load_font(name, size):
    path = os.path.join(ASSETS, "fonts", name)
    if os.path.exists(path):
        return pygame.font.Font(path, size)
    if name.endswith(".otf"):
        alt = name[:-4] + ".ttf"
    elif name.endswith(".ttf"):
        alt = name[:-4] + ".otf"
    else:
        alt = None
    if alt:
        alt_path = os.path.join(ASSETS, "fonts", alt)
        if os.path.exists(alt_path):
            return pygame.font.Font(alt_path, size)
    return pygame.font.SysFont("arial", size, bold=True)


FONT_FILE   = "FatPix-SVG.otf"
LETTER_FONT = "DaintyCute.otf"
LETTER_FILE = "assets/letter.txt"

UI_MAIN   = (255, 215, 140)
UI_SHADOW = (110, 55, 30)

TITLE_COLOR        = (255, 155, 120)
TITLE_SHADOW_COLOR = (140, 60, 45)


class EndScene(Scene):
    """Envelope scene with scrollable letter. All sprite coordinates
    below are in NATIVE letter.png pixels — the code multiplies by
    SCROLL_SCALE when drawing."""

    LETTER_SLIDE_TIME = 1.2
    DIM_ALPHA         = 170
    SCROLL_WHEEL_STEP = 40
    ARROW_KEY_STEP    = 30

    # Scale applied to letter.png
    SCROLL_SCALE = 13

    # Gap above / below the scroll window on screen
    SCROLL_TOP_OFFSET    = 40
    SCROLL_BOTTOM_OFFSET = 40

    # ---- Positions in NATIVE sprite pixels ----
    TITLE_POS      = (2, 2)       # top-left of "For my love"
    TEXT_START     = (5, 8)       # first letter of the letter body
    BTN_START_POS  = (9, 74)
    BTN_RESET_POS  = (22, 74)

    # ---- Font sizes (canvas pixels) ----
    TITLE_FONT_SIZE = 26
    BODY_FONT_SIZE  = 16
    BTN_FONT_SIZE   = 16

    UI_TITLE_SIZE = 34            # top-screen FatPix title

    # ---- Button sizes (canvas pixels) ----
    BTN_W = 130
    BTN_H = 34

    def __init__(self, manager):
        super().__init__(manager)
        self.screen_w, self.screen_h = 640, 480

        # Fonts
        self.title_font    = load_font(LETTER_FONT, self.TITLE_FONT_SIZE)
        self.title_ui_font = load_font(FONT_FILE, self.UI_TITLE_SIZE)
        self.hint_font     = load_font(FONT_FILE, 14)
        self.body_font     = load_font(LETTER_FONT, self.BODY_FONT_SIZE)
        self.btn_font      = load_font(LETTER_FONT, self.BTN_FONT_SIZE)
        self.tiny_font     = load_font(LETTER_FONT, 12)
        self.confirm_font  = load_font(LETTER_FONT, 22)
        self.confirm_body  = load_font(LETTER_FONT, 14)
        self.confirm_btn   = load_font(LETTER_FONT, 14)

        # Background
        self.bg = load_image_native(asset("sprites", "bedroom_bg.png"),
                                    fallback_color=(240, 200, 170))
        self.bg = pygame.transform.scale(self.bg, (self.screen_w, self.screen_h))

        # Envelope mask
        self.envelope_mask = load_image_native(asset("sprites", "envelope_mask.png"))
        self.envelope_mask_has_sprite = os.path.exists(
            asset("sprites", "envelope_mask.png"))
        self.envelope_mask = pygame.transform.scale(
            self.envelope_mask, (self.screen_w, self.screen_h))
        self.envelope_rect = self._mask_bounding_rect()

        # ---- letter.png at SCROLL_SCALE × ----
        raw_scroll = load_image_native(asset("sprites", "letter.png"),
                                       fallback_color=(250, 240, 215))
        self.scroll_has_sprite = os.path.exists(asset("sprites", "letter.png"))
        raw_w, raw_h = raw_scroll.get_size()
        self.scroll_w = raw_w * self.SCROLL_SCALE
        self.scroll_h = raw_h * self.SCROLL_SCALE
        self.scroll_img = pygame.transform.scale(
            raw_scroll, (self.scroll_w, self.scroll_h))

        # ---- Heart sprite ----
        self.heart_img = load_image_native(asset("sprites", "heart.png"))
        self.heart_has_sprite = os.path.exists(asset("sprites", "heart.png"))
        heart_size = self.TITLE_FONT_SIZE
        self.heart_img = pygame.transform.scale(self.heart_img,
                                                (heart_size, heart_size))

        # ---- Letter text ----
        if os.path.exists(LETTER_FILE):
            with open(LETTER_FILE, "r", encoding="utf-8") as f:
                self.letter_text = f.read()
        else:
            self.letter_text = (
                "Dear Pookiebear :P,\n" \
                "\n"\
                "Crazy to think that it has been already been a year since we started this relationship, and I can say that this has been the happiest I have been, mainly because of you :)\n" \
                "\n"\
                "From the time that we went on our first date to the time that we went to disneyland together, I looked forward to every activity and date that we went on and have enjoyed every one of them\n" \
                "\n"\
                "And even if I was not able to spend our anniversary physically, I hope that this game that I made for you showed that you are my world, my soulmate, my forever, and my future wifey :D\n" \
                "\n"\
                "I wish to travel with you, eat all the food we can together, cuddle in bed every night, and grow old together while being as clingy as we are :P\n" \
                "\n"\
                "There are too many reasons why I love you, but the main reason is because you make me feel like myself, and I can't love you enough for it <3\n" \
                "\n"\
                "Despite all the dificulties we might face in the future, I would always want to have you in my life and live my life with you\n" \
                "\n"\
                "I love you Christine, and I forever will <3\n" \
                "\n"\
                "Yours always,\n" \
                "Jonam <3\n" \
                "\n"\
                "(PS: To replay the game, press 'Start Over' :P)"
            )

        # Wrap text to fit inside the scroll
        text_x = self.TEXT_START[0] * self.SCROLL_SCALE
        text_width = self.scroll_w - text_x - (self.TEXT_START[0] * self.SCROLL_SCALE)
        self.wrapped_lines = self._wrap(
            self.letter_text, self.body_font, text_width)
        self.line_height = self.body_font.get_linesize() + 4

        # Visible window
        self.visible_height = self.screen_h - (
            self.SCROLL_TOP_OFFSET + self.SCROLL_BOTTOM_OFFSET)
        self.max_scroll = max(0, self.scroll_h - self.visible_height)
        self.scroll_y = 0

        # Button rects
        self.btn_restart_rect = None
        self.btn_reset_rect = None

        # Confirm dialog
        self.confirming = False
        self.confirm_hover = None

        # State
        self.state = "idle"
        self.letter_t = 0.0
        self.hover = False
        self.hover_btn = None
        self.t = 0.0

    # ------------------------------------------------------------------
    def _mask_bounding_rect(self):
        if not self.envelope_mask_has_sprite:
            return pygame.Rect(320 - 40, 280 - 25, 80, 50)
        mask = pygame.mask.from_surface(self.envelope_mask)
        rects = mask.get_bounding_rects()
        if not rects:
            return pygame.Rect(320 - 40, 280 - 25, 80, 50)
        union = rects[0]
        for r in rects[1:]:
            union = union.union(r)
        return union.inflate(10, 10)

    # ------------------------------------------------------------------
    def _wrap(self, text, font, max_width):
        result = []
        for paragraph in text.split("\n"):
            if paragraph == "":
                result.append("")
                continue
            words = paragraph.split(" ")
            current = ""
            for w in words:
                trial = (current + " " + w).strip()
                if font.size(trial)[0] <= max_width:
                    current = trial
                else:
                    if current:
                        result.append(current)
                    current = w
            if current:
                result.append(current)
        return result

    # ------------------------------------------------------------------
    def _confirm_rects(self):
        yes_rect = pygame.Rect(155, 300, 150, 50)
        no_rect  = pygame.Rect(335, 300, 150, 50)
        return yes_rect, no_rect

    # ------------------------------------------------------------------
    def handle_event(self, event):
        # Confirm dialog intercepts everything while active
        if self.confirming:
            self._handle_confirm_event(event)
            return

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self._back_to_idle()
                return
            if self.state == "ready":
                if event.key == pygame.K_DOWN:
                    self.scroll_y = min(self.scroll_y + self.ARROW_KEY_STEP,
                                        self.max_scroll)
                elif event.key == pygame.K_UP:
                    self.scroll_y = max(self.scroll_y - self.ARROW_KEY_STEP, 0)

        elif event.type == pygame.MOUSEMOTION:
            if self.state == "idle":
                self.hover = self.envelope_rect.collidepoint(event.pos)
            elif self.state == "ready":
                scroll_x = 320 - self.scroll_w // 2
                mx = event.pos[0] - scroll_x
                my = event.pos[1] - self.SCROLL_TOP_OFFSET + self.scroll_y
                self.hover_btn = None
                if self.btn_restart_rect and self.btn_restart_rect.collidepoint((mx, my)):
                    self.hover_btn = "restart"
                elif self.btn_reset_rect and self.btn_reset_rect.collidepoint((mx, my)):
                    self.hover_btn = "reset"

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.state == "idle" and self.envelope_rect.collidepoint(event.pos):
                self._start_open()
            elif self.state == "ready":
                scroll_x = 320 - self.scroll_w // 2
                mx = event.pos[0] - scroll_x
                my = event.pos[1] - self.SCROLL_TOP_OFFSET + self.scroll_y
                if self.btn_restart_rect and self.btn_restart_rect.collidepoint((mx, my)):
                    self._ask_confirm()
                elif self.btn_reset_rect and self.btn_reset_rect.collidepoint((mx, my)):
                    self._back_to_title()

        elif event.type == pygame.MOUSEWHEEL:
            if self.state == "ready":
                self.scroll_y = max(0, min(
                    self.scroll_y - event.y * self.SCROLL_WHEEL_STEP,
                    self.max_scroll))

    # ------------------------------------------------------------------
    def _handle_confirm_event(self, event):
        yes_rect, no_rect = self._confirm_rects()

        if event.type == pygame.MOUSEMOTION:
            if yes_rect.collidepoint(event.pos):
                self.confirm_hover = "yes"
            elif no_rect.collidepoint(event.pos):
                self.confirm_hover = "no"
            else:
                self.confirm_hover = None

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if yes_rect.collidepoint(event.pos):
                self._do_restart()
            elif no_rect.collidepoint(event.pos):
                self.confirming = False
                self.confirm_hover = None

        elif event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_y, pygame.K_RETURN):
                self._do_restart()
            elif event.key in (pygame.K_n, pygame.K_ESCAPE):
                self.confirming = False
                self.confirm_hover = None

    # ------------------------------------------------------------------
    def _start_open(self):
        self.state = "sliding"
        self.letter_t = 0.0

    def _ask_confirm(self):
        """Show the confirmation dialog before wiping."""
        self.confirming = True
        self.confirm_hover = None

    def _do_restart(self):
        """Player confirmed — wipe progress and go to title."""
        self.manager.progress["completed"] = []
        self.manager.progress["intro_seen"] = False
        from scenes.start import StartScene
        self.manager.go_to(lambda: StartScene(self.manager))

    def _back_to_title(self):
        # Signal the start screen to show the quizmaster dialogue
        self.manager.progress["returned_to_title"] = True
        from scenes.start import StartScene
        self.manager.go_to(lambda: StartScene(self.manager))

    def _back_to_idle(self):
        """ESC — return to the bedroom view (envelope on the desk)."""
        self.state = "idle"
        self.letter_t = 0.0
        self.scroll_y = 0
        self.hover = False
        self.hover_btn = None

    def _leave(self):
        from scenes.hub import HubScene
        self.manager.go_to(lambda: HubScene(self.manager))

    # ------------------------------------------------------------------
    def update(self, dt):
        self.t += dt
        if self.state == "sliding":
            self.letter_t += dt
            if self.letter_t >= self.LETTER_SLIDE_TIME:
                self.state = "ready"
                self.letter_t = 0.0

    # ------------------------------------------------------------------
    def _draw_button(self, surface, rect, label, hovered):
        if hovered:
            bg = (255, 220, 170)
            border = (200, 130, 80)
            txt = (120, 60, 40)
        else:
            bg = (250, 235, 210)
            border = (170, 120, 90)
            txt = (90, 55, 40)

        pygame.draw.rect(surface, bg, rect, border_radius=6)
        pygame.draw.rect(surface, border, rect, 2, border_radius=6)
        surf = self.btn_font.render(label, True, txt)
        surface.blit(surf, (rect.centerx - surf.get_width() // 2,
                            rect.centery - surf.get_height() // 2))

    # ------------------------------------------------------------------
    def _render_scroll_canvas(self):
        canvas = pygame.Surface((self.scroll_w, self.scroll_h), pygame.SRCALPHA)

        # The scaled letter.png
        canvas.blit(self.scroll_img, (0, 0))

        # Title "For my love" — BLACK
        title_x = self.TITLE_POS[0] * self.SCROLL_SCALE
        title_y = self.TITLE_POS[1] * self.SCROLL_SCALE
        title_surf = self.title_font.render("For my love", True, (0, 0, 0))
        canvas.blit(title_surf, (title_x, title_y))

        # Heart sprite right after the title
        if self.heart_has_sprite:
            heart_x = title_x + title_surf.get_width() + 6
            heart_y = title_y + (title_surf.get_height()
                                 - self.heart_img.get_height()) // 2 - 3
            canvas.blit(self.heart_img, (heart_x, heart_y))

        # Letter body — with inline heart support via "<3"
        text_x = self.TEXT_START[0] * self.SCROLL_SCALE
        text_y = self.TEXT_START[1] * self.SCROLL_SCALE
        heart_size = self.body_font.get_height() - 4

        for line in self.wrapped_lines:
            if line == "":
                text_y += self.line_height
                continue

            if "<3" in line and self.heart_has_sprite:
                # Split and render text/heart alternating
                parts = line.split("<3")
                segs = []
                for j, part in enumerate(parts):
                    if part:
                        segs.append(("text", part))
                    if j < len(parts) - 1:
                        segs.append(("heart", None))

                cx = text_x
                for kind, part in segs:
                    if kind == "text":
                        ts = self.body_font.render(part, True, (60, 40, 30))
                        canvas.blit(ts, (cx, text_y))
                        cx += ts.get_width()
                    else:
                        scaled_heart = pygame.transform.scale(
                            self.heart_img, (heart_size, heart_size)
                        )
                        hy = text_y + (self.line_height - heart_size) // 2 - 3
                        canvas.blit(scaled_heart, (cx, hy))
                        cx += heart_size + 4
            else:
                surf = self.body_font.render(line, True, (60, 40, 30))
                canvas.blit(surf, (text_x, text_y))

            text_y += self.line_height

        # Buttons
        btn_start_x = self.BTN_START_POS[0] * self.SCROLL_SCALE
        btn_start_y = self.BTN_START_POS[1] * self.SCROLL_SCALE
        btn_reset_x = self.BTN_RESET_POS[0] * self.SCROLL_SCALE
        btn_reset_y = self.BTN_RESET_POS[1] * self.SCROLL_SCALE

        self.btn_restart_rect = pygame.Rect(
            btn_start_x, btn_start_y, self.BTN_W, self.BTN_H)
        self.btn_reset_rect = pygame.Rect(
            btn_reset_x, btn_reset_y, self.BTN_W, self.BTN_H)

        self._draw_button(canvas, self.btn_restart_rect, "Start Over",
                          self.hover_btn == "restart")
        self._draw_button(canvas, self.btn_reset_rect, "Back to Title",
                          self.hover_btn == "reset")

        return canvas

    # ------------------------------------------------------------------
    def _draw_ui_text_center(self, screen, font, text, cx, y,
                             main=UI_MAIN, shadow=UI_SHADOW):
        main_surf = font.render(text, False, main)
        shadow_surf = font.render(text, False, shadow)
        x = cx - main_surf.get_width() // 2
        screen.blit(shadow_surf, (x + 2, y + 2))
        screen.blit(main_surf,   (x,     y))

    # ------------------------------------------------------------------
    def _draw_confirm(self, screen):
        # Dim everything
        overlay = pygame.Surface((self.screen_w, self.screen_h),
                                 pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))

        # Panel
        panel = pygame.Rect(120, 150, 400, 230)
        pygame.draw.rect(screen, (35, 30, 55), panel, border_radius=14)
        pygame.draw.rect(screen, (200, 140, 140), panel, 3, border_radius=14)

        # Title
        title = self.confirm_font.render("Are you sure?", True, (255, 200, 200))
        screen.blit(title, (320 - title.get_width() // 2, 175))

        # Body lines
        line1 = self.confirm_body.render(
            "This will erase all your progress", True, (230, 230, 240))
        line2 = self.confirm_body.render(
            "and lock every gate again.", True, (230, 230, 240))
        screen.blit(line1, (320 - line1.get_width() // 2, 220))
        screen.blit(line2, (320 - line2.get_width() // 2, 242))

        # Buttons
        yes_rect, no_rect = self._confirm_rects()

        if self.confirm_hover == "yes":
            yes_bg = (180, 70, 70)
            yes_border = (255, 160, 160)
        else:
            yes_bg = (110, 55, 55)
            yes_border = (200, 120, 120)

        pygame.draw.rect(screen, yes_bg, yes_rect, border_radius=10)
        pygame.draw.rect(screen, yes_border, yes_rect, 2, border_radius=10)
        yes_label = self.confirm_btn.render("Yes, erase it", True,
                                            (255, 255, 255))
        screen.blit(yes_label, (yes_rect.centerx - yes_label.get_width() // 2,
                                yes_rect.centery - yes_label.get_height() // 2))

        if self.confirm_hover == "no":
            no_bg = (90, 130, 190)
            no_border = (200, 220, 255)
        else:
            no_bg = (50, 60, 100)
            no_border = (140, 150, 200)

        pygame.draw.rect(screen, no_bg, no_rect, border_radius=10)
        pygame.draw.rect(screen, no_border, no_rect, 2, border_radius=10)
        no_label = self.confirm_btn.render("No, go back", True,
                                           (230, 230, 240))
        screen.blit(no_label, (no_rect.centerx - no_label.get_width() // 2,
                               no_rect.centery - no_label.get_height() // 2))

    # ------------------------------------------------------------------
    def draw(self, screen):
        # Background
        screen.blit(self.bg, (0, 0))

        # FatPix title
        self._draw_ui_text_center(
            screen, self.title_ui_font, "A letter for you",
            320, 20,
            main=TITLE_COLOR, shadow=TITLE_SHADOW_COLOR)

        # Hint under the title
        self._draw_ui_text_center(
            screen, self.hint_font, "Click the envelope to open it",
            320, 70, main=UI_MAIN, shadow=UI_SHADOW)

        # Idle
        if self.state == "idle":
            if self.hover:
                pulse = 0.5 + 0.5 * pygame.math.Vector2(1, 0).rotate(
                    self.t * 180).x
                glow_alpha = int(60 + 70 * pulse)
                if self.envelope_mask_has_sprite:
                    glow = self.envelope_mask.copy()
                    glow.fill((255, 220, 150, 255),
                              special_flags=pygame.BLEND_RGBA_MULT)
                    glow.set_alpha(glow_alpha)
                    screen.blit(glow, (0, 0),
                                special_flags=pygame.BLEND_RGBA_ADD)
            if self.confirming:
                self._draw_confirm(screen)
            return

        # Dim
        if self.state == "sliding":
            p = min(self.letter_t / self.LETTER_SLIDE_TIME, 1.0)
            eased = 1 - (1 - p) ** 3
        else:
            eased = 1.0

        dim_alpha = int(self.DIM_ALPHA * eased)
        dim = pygame.Surface((self.screen_w, self.screen_h), pygame.SRCALPHA)
        dim.fill((20, 10, 5, dim_alpha))
        screen.blit(dim, (0, 0))

        # Scroll
        canvas = self._render_scroll_canvas()

        scroll_x = 320 - self.scroll_w // 2
        scroll_y_pos = int(self.SCROLL_TOP_OFFSET
                           + (1 - eased) * 480 - self.scroll_y)

        old_clip = screen.get_clip()
        screen.set_clip(pygame.Rect(
            scroll_x,
            self.SCROLL_TOP_OFFSET,
            self.scroll_w,
            self.visible_height))
        screen.blit(canvas, (scroll_x, scroll_y_pos))
        screen.set_clip(old_clip)

        # Scroll hint
        if (self.state == "ready" and self.max_scroll > 0
                and self.scroll_y < self.max_scroll):
            hint = self.tiny_font.render("Scroll to read more", True,
                                         (255, 230, 180))
            hs = self.tiny_font.render("Scroll to read more", True,
                                       (110, 55, 30))
            hx = 320 - hint.get_width() // 2
            screen.blit(hs, (hx + 2, 456))
            screen.blit(hint, (hx, 454))

        # Confirm dialog on top of the letter if active
        if self.confirming:
            self._draw_confirm(screen)
import os
import pygame
from scenes.base_scene import Scene

ASSETS = "assets"
def asset(*parts):
    return os.path.join(ASSETS, *parts)


def load_image(path, size, fallback_color=None):
    if os.path.exists(path):
        img = pygame.image.load(path).convert_alpha()
        return pygame.transform.scale(img, size)
    surf = pygame.Surface(size, pygame.SRCALPHA)
    if fallback_color:
        surf.fill(fallback_color)
    return surf


def load_font(name, size):
    path = os.path.join(ASSETS, "fonts", name)
    if os.path.exists(path):
        return pygame.font.Font(path, size)
    if name.endswith(".otf"):
        alt = name[:-4] + ".ttf"
    elif name.endswith(".ttf"):
        alt = name[:-4] + ".otf"
    else:
        alt = None
    if alt:
        alt_path = os.path.join(ASSETS, "fonts", alt)
        if os.path.exists(alt_path):
            return pygame.font.Font(alt_path, size)
    return pygame.font.SysFont("arial", size, bold=True)


FONT_FILE     = "FatPix-SVG.otf"
TUTORIAL_FONT = "DaintyCute.otf"

UI_MAIN   = (255, 215, 140)
UI_SHADOW = (110, 55, 30)


# ==================================================================
# EDIT RETURN-TO-TITLE DIALOGUE HERE
# ==================================================================
RETURN_DIALOGUE = [
    "Hey Pooks :P",
    "Thank you for playing my game :)",
    "If you want to look around you can",
    "And if you want to play the game again\n you can click 'Start Over' on the letter :)",
    "I love you :P"
]

SPEAKER_NAME = "Jonam"

# Quizmaster sprite and dialogue box (same setup as entrance and quiz)
QUIZMASTER_SIZE     = (171, 279)
QUIZMASTER_OFFSET_Y = -30
BOX_HEIGHT          = 130


class StartScene(Scene):
    TITLE_SIZE = 72
    OUTLINE_THICKNESS = 3
    SIDE_OFFSET = 3

    # --- The three colors ---
    COLOR_MAIN    = (255, 155, 120)
    COLOR_SIDE    = (200, 105, 75)
    COLOR_OUTLINE = (255, 255, 255)

    def __init__(self, manager):
        super().__init__(manager)
        self.screen_w, self.screen_h = 640, 480

        # Fonts
        self.title_font    = load_font(FONT_FILE, self.TITLE_SIZE)
        self.hint_font     = load_font(FONT_FILE, 18)
        self.ui_small      = load_font(FONT_FILE, 14)
        self.ui_tiny       = load_font(FONT_FILE, 11)
        self.dialogue_font = load_font(TUTORIAL_FONT, 22)

        # Background
        self.bg = load_image(
            asset("sprites", "start_bg.png"),
            (self.screen_w, self.screen_h),
            fallback_color=(255, 220, 200)
        )

        # Title
        self.title_text = "Our Home"
        self.title_surf = self._build_title_surface()
        self.title_rect = self.title_surf.get_rect()
        self.title_rect.center = (self.screen_w // 2, 70)

        # Clickable door area
        self.door_rect = pygame.Rect(280, 230, 80, 180)
        self.door_hover = False

        # Quizmaster sprite
        self.quizmaster = load_image(
            asset("sprites", "quizmaster.png"),
            QUIZMASTER_SIZE,
            fallback_color=None
        )
        self.quizmaster_has_sprite = os.path.exists(
            asset("sprites", "quizmaster.png")
        )

        # Return dialogue flag
        self.show_return_dialogue = bool(
            self.manager.progress.get("returned_to_title")
        )
        self.dialogue_line = 0
        self.dialogue_timer = 0.0

        self.t = 0.0

    # ------------------------------------------------------------------
    def _build_title_surface(self):
        text = self.title_text
        t = self.OUTLINE_THICKNESS
        off = self.SIDE_OFFSET

        white_surf = self.title_font.render(text, False, self.COLOR_OUTLINE)
        side_surf  = self.title_font.render(text, False, self.COLOR_SIDE)
        main_surf  = self.title_font.render(text, False, self.COLOR_MAIN)

        pad_x = t + off
        pad_y = t + off
        surf = pygame.Surface(
            (main_surf.get_width() + pad_x * 2,
             main_surf.get_height() + pad_y * 2),
            pygame.SRCALPHA
        )

        base_x = pad_x
        base_y = pad_y

        # 1. White outline
        for dx in range(-t, t + 1):
            for dy in range(-t, t + 1):
                if dx == 0 and dy == 0:
                    continue
                surf.blit(white_surf, (base_x + dx, base_y + dy))

        # 2. Dark side
        surf.blit(side_surf, (base_x + off, base_y + off))

        # 3. Main fill
        surf.blit(main_surf, (base_x, base_y))

        return surf

    # ------------------------------------------------------------------
    def _quizmaster_pos(self):
        qw, qh = QUIZMASTER_SIZE
        qx = 320 - qw // 2
        qy = 240 - qh // 2 + QUIZMASTER_OFFSET_Y
        return (qx, qy)

    # ------------------------------------------------------------------
    def handle_event(self, event):
        # Quizmaster return dialogue takes over all input
        if self.show_return_dialogue:
            if (event.type == pygame.KEYDOWN or
                    (event.type == pygame.MOUSEBUTTONDOWN
                     and event.button == 1)):
                self.dialogue_line += 1
                if self.dialogue_line >= len(RETURN_DIALOGUE):
                    self.show_return_dialogue = False
                    self.manager.progress["returned_to_title"] = False
            return

        # Normal start screen input
        if event.type == pygame.MOUSEMOTION:
            self.door_hover = self.door_rect.collidepoint(event.pos)

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.door_rect.collidepoint(event.pos):
                self._start_game()

        elif event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                self._start_game()

    # ------------------------------------------------------------------
    def _start_game(self):
        if self.manager.progress.get("intro_seen"):
            from scenes.hub import HubScene
            self.manager.go_to(lambda: HubScene(self.manager))
        else:
            from scenes.entrance import EntranceScene
            self.manager.go_to(lambda: EntranceScene(self.manager))

    # ------------------------------------------------------------------
    def update(self, dt):
        self.t += dt
        if self.show_return_dialogue:
            self.dialogue_timer += dt

    # ------------------------------------------------------------------
    def draw(self, screen):
        screen.blit(self.bg, (0, 0))

        # Title
        bob = int(3 * pygame.math.Vector2(1, 0).rotate(self.t * 90).y)
        rect = self.title_rect.copy()
        rect.y += bob
        screen.blit(self.title_surf, rect.topleft)

        # Bottom hint
        hint = self.hint_font.render(
            "Press the door to start", False, (255, 250, 235)
        )
        hint_shadow = self.hint_font.render(
            "Press the door to start", False, (120, 70, 50)
        )
        hint_x = self.screen_w // 2 - hint.get_width() // 2
        screen.blit(hint_shadow, (hint_x + 1, 453))
        screen.blit(hint,        (hint_x,     452))

        # Return dialogue
        if self.show_return_dialogue:
            self._draw_return_dialogue(screen)

    # ------------------------------------------------------------------
    def _draw_return_dialogue(self, screen):
        # Dim the start screen
        dim = pygame.Surface((640, 480), pygame.SRCALPHA)
        dim.fill((20, 10, 5, 150))
        screen.blit(dim, (0, 0))

        # Quizmaster sprite
        if self.quizmaster_has_sprite:
            screen.blit(self.quizmaster, self._quizmaster_pos())

        # Dialogue box
        box = pygame.Rect(20, 480 - BOX_HEIGHT - 16, 640 - 40, BOX_HEIGHT)

        shadow = pygame.Surface((box.width + 12, box.height + 12),
                                pygame.SRCALPHA)
        shadow.fill((30, 15, 10, 90))
        screen.blit(shadow, (box.x + 6, box.y + 8))

        pygame.draw.rect(screen, (245, 230, 200), box, border_radius=12)
        pygame.draw.rect(screen, (150, 90, 60), box, 4, border_radius=12)

        # Speaker
        speaker_surf = self.ui_small.render(SPEAKER_NAME, False, (150, 70, 50))
        screen.blit(speaker_surf, (box.left + 20, box.top + 14))

        # Dialogue text
        if self.dialogue_line < len(RETURN_DIALOGUE):
            text = RETURN_DIALOGUE[self.dialogue_line]
            max_text_width = box.width - 40

            wrapped = []
            for paragraph in text.split("\n"):
                if paragraph == "":
                    wrapped.append("")
                    continue
                words = paragraph.split(" ")
                current = ""
                for w in words:
                    trial = (current + " " + w).strip()
                    if self.dialogue_font.size(trial)[0] <= max_text_width:
                        current = trial
                    else:
                        if current:
                            wrapped.append(current)
                        current = w
                if current:
                    wrapped.append(current)

            line_height = self.dialogue_font.get_linesize() + 2
            total_height = len(wrapped) * line_height
            start_y = box.top + 42 + max(0, (60 - total_height) // 2)

            for i, line in enumerate(wrapped):
                if line == "":
                    continue
                surf = self.dialogue_font.render(line, True, (90, 55, 40))
                screen.blit(surf, (box.centerx - surf.get_width() // 2,
                                   start_y + i * line_height))

        # Pulsing hint
        pulse = 0.5 + 0.5 * pygame.math.Vector2(1, 0).rotate(
            self.dialogue_timer * 200
        ).x
        shade = int(150 + 80 * pulse)
        hint = self.ui_tiny.render(
            "Click or press any key to continue",
            False, (shade, shade - 30, shade - 60)
        )
        screen.blit(hint, (box.centerx - hint.get_width() // 2,
                           box.bottom - 24))

        # Arrow
        ax = box.right - 30
        ay = box.bottom - 22
        pygame.draw.polygon(screen, (150, 90, 60), [
            (ax, ay - 4),
            (ax + 8, ay - 4),
            (ax + 4, ay + 4),
        ])
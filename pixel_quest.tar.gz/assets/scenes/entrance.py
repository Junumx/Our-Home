import os
import pygame
from scenes.base_scene import Scene

ASSETS = "assets"
def asset(*parts):
    return os.path.join(ASSETS, *parts)


def load_image(path, size, fallback_color=None):
    if os.path.exists(path):
        img = pygame.image.load(path).convert_alpha()
        return pygame.transform.scale(img, size)
    surf = pygame.Surface(size, pygame.SRCALPHA)
    if fallback_color:
        surf.fill(fallback_color)
    return surf


def load_font(name, size):
    path = os.path.join(ASSETS, "fonts", name)
    if os.path.exists(path):
        return pygame.font.Font(path, size)
    if name.endswith(".otf"):
        alt = name[:-4] + ".ttf"
    elif name.endswith(".ttf"):
        alt = name[:-4] + ".otf"
    else:
        alt = None
    if alt:
        alt_path = os.path.join(ASSETS, "fonts", alt)
        if os.path.exists(alt_path):
            return pygame.font.Font(alt_path, size)
    return pygame.font.SysFont("arial", size, bold=True)


FONT_FILE     = "FatPix-SVG.otf"
TUTORIAL_FONT = "DaintyCute.otf"

UI_MAIN   = (255, 215, 140)
UI_SHADOW = (110, 55, 30)


# ==================================================================
# EDIT YOUR DIALOGUE HERE
# Each string is one line, shown one at a time.
# ==================================================================
INTRO_DIALOGUE = [
    "Welcome home sweetheart! :)",
    "I made you a small game for you to play for our anniversary :P",
    "You have to complete the four games that I made to see the suprise",
    "I hope you enjoy my game hehe (It took a while to make :P)",
    "Kissies :D",
]

# Name shown at the top-left of the dialogue box
SPEAKER_NAME = "Jonam"


class EntranceScene(Scene):
    KEY = "intro"

    # Quizmaster sprite — same size and offset as quiz.py
    QUIZMASTER_SIZE     = (171, 279)
    QUIZMASTER_OFFSET_Y = -30

    # Dialogue box height — same as quiz.py
    BOX_HEIGHT = 130

    # Title at top-left of the screen
    TITLE_TEXT = "Jonam"
    TITLE_POS  = (20, 16)

    def __init__(self, manager):
        super().__init__(manager)
        self.screen_w, self.screen_h = 640, 480

        # Fonts — same setup as quiz.py
        self.ui_font    = load_font(FONT_FILE, 18)
        self.ui_small   = load_font(FONT_FILE, 14)
        self.ui_tiny    = load_font(FONT_FILE, 11)
        self.ui_large   = load_font(FONT_FILE, 30)

        self.tut_font   = load_font(TUTORIAL_FONT, 22)
        self.tut_answer = load_font(TUTORIAL_FONT, 18)

        # Background
        self.bg = load_image(
            asset("sprites", "entrance_bg.png"),
            (self.screen_w, self.screen_h),
            fallback_color=(240, 200, 170)
        )

        # Quizmaster sprite
        self.quizmaster = load_image(
            asset("sprites", "quizmaster.png"),
            self.QUIZMASTER_SIZE,
            fallback_color=None
        )
        self.quizmaster_has_sprite = os.path.exists(
            asset("sprites", "quizmaster.png")
        )

        self.reset()

    # ------------------------------------------------------------------
    def reset(self):
        self.dialogue_line = 0
        self.timer = 0.0

    # ------------------------------------------------------------------
    def _quizmaster_pos(self):
        """Same formula as quiz.py."""
        qw, qh = self.QUIZMASTER_SIZE
        qx = 320 - qw // 2
        qy = 240 - qh // 2 + self.QUIZMASTER_OFFSET_Y
        return (qx, qy)

    # ------------------------------------------------------------------
    def _admin_combo(self):
        keys = pygame.key.get_pressed()
        return (keys[pygame.K_LCTRL] and
                keys[pygame.K_LSHIFT] and
                keys[pygame.K_k])

    # ------------------------------------------------------------------
    def _advance_dialogue(self):
        self.dialogue_line += 1
        if self.dialogue_line >= len(INTRO_DIALOGUE):
            self._finish()

    def _finish(self):
        # Mark the intro as seen so it doesn't replay
        self.manager.progress["intro_seen"] = True
        from scenes.hub import HubScene
        self.manager.go_to(lambda: HubScene(self.manager))

    def _leave(self):
        from scenes.start import StartScene
        self.manager.go_to(lambda: StartScene(self.manager))

    # ------------------------------------------------------------------
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self._leave()
                return

            if event.key == pygame.K_k and self._admin_combo():
                self._finish()
                return

            # Any other key advances the dialogue
            self._advance_dialogue()

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self._advance_dialogue()

    # ------------------------------------------------------------------
    def update(self, dt):
        self.timer += dt

    # ------------------------------------------------------------------
    def _wrap_text(self, text, font, max_width):
        """Same wrapping as quiz.py."""
        result = []
        for paragraph in text.split("\n"):
            if paragraph == "":
                result.append("")
                continue
            words = paragraph.split(" ")
            current = ""
            for w in words:
                trial = (current + " " + w).strip()
                if font.size(trial)[0] <= max_width:
                    current = trial
                else:
                    if current:
                        result.append(current)
                    current = w
            if current:
                result.append(current)
        return result

    # ------------------------------------------------------------------
    def draw(self, screen):
        # Background
        screen.blit(self.bg, (0, 0))

        # Quizmaster — same position as quiz.py
        if self.quizmaster_has_sprite:
            screen.blit(self.quizmaster, self._quizmaster_pos())

        # --- Dialogue box — same as quiz.py ---
        box = pygame.Rect(20, self.screen_h - self.BOX_HEIGHT - 16,
                          self.screen_w - 40, self.BOX_HEIGHT)

        # Drop shadow
        shadow = pygame.Surface((box.width + 12, box.height + 12),
                                pygame.SRCALPHA)
        shadow.fill((30, 15, 10, 90))
        screen.blit(shadow, (box.x + 6, box.y + 8))

        # Opaque cream panel — rounded corners
        pygame.draw.rect(screen, (245, 230, 200), box, border_radius=12)
        pygame.draw.rect(screen, (150, 90, 60), box, 4, border_radius=12)

        # Dialogue text — same rendering as quiz.py
        if self.dialogue_line < len(INTRO_DIALOGUE):
            self._draw_dialogue_phase(
                screen, box,
                [INTRO_DIALOGUE[self.dialogue_line]], 0
            )

    # ------------------------------------------------------------------
    def _draw_dialogue_phase(self, screen, box, lines, line_index,
                             speaker=SPEAKER_NAME):
        """Same as quiz.py's _draw_dialogue_phase."""
        speaker_surf = self.ui_small.render(speaker, False, (150, 70, 50))
        screen.blit(speaker_surf, (box.left + 20, box.top + 14))

        max_text_width = box.width - 40
        wrapped = self._wrap_text(lines[line_index], self.tut_font,
                                  max_text_width)

        line_height = self.tut_font.get_linesize() + 2
        total_height = len(wrapped) * line_height
        start_y = box.top + 42 + max(0, (60 - total_height) // 2)

        for i, line in enumerate(wrapped):
            if line == "":
                continue
            text_surf = self.tut_font.render(line, True, (90, 55, 40))
            screen.blit(text_surf,
                        (box.centerx - text_surf.get_width() // 2,
                         start_y + i * line_height))

        # Pulsing "click to continue" hint
        pulse = 0.5 + 0.5 * pygame.math.Vector2(1, 0).rotate(
            self.timer * 200).x
        shade = int(150 + 80 * pulse)
        hint = self.ui_tiny.render(
            "Click or press any key to continue",
            False, (shade, shade - 30, shade - 60)
        )
        screen.blit(hint, (box.centerx - hint.get_width() // 2,
                           box.bottom - 24))

        # Small arrow indicator
        ax = box.right - 30
        ay = box.bottom - 22
        pygame.draw.polygon(screen, (150, 90, 60), [
            (ax, ay - 4),
            (ax + 8, ay - 4),
            (ax + 4, ay + 4),
        ])
class Scene:
    """Base class every screen inherits from.

    A Scene is one "screen" of the game — the title, the hub, one minigame,
    the end screen. The SceneManager swaps between them.
    """

    def __init__(self, manager):
        self.manager = manager

    def handle_event(self, event):
        """Called once per pygame event (keypress, mouse click, quit, ...)."""
        pass

    def update(self, dt):
        """Called every frame. `dt` is seconds since the last frame."""
        pass

    def draw(self, screen):
        """Called every frame. Draw the current state to the screen surface."""
        pass
    
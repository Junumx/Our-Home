import os
import random
import pygame
from scenes.base_scene import Scene

ASSETS = "assets"
def asset(*parts):
    return os.path.join(ASSETS, *parts)


def load_image(path, size, fallback_color=None):
    if os.path.exists(path):
        img = pygame.image.load(path).convert_alpha()
        return pygame.transform.scale(img, size)
    surf = pygame.Surface(size, pygame.SRCALPHA)
    if fallback_color:
        surf.fill(fallback_color)
    return surf


def load_font(name, size):
    path = os.path.join(ASSETS, "fonts", name)
    if os.path.exists(path):
        return pygame.font.Font(path, size)
    if name.endswith(".otf"):
        alt = name[:-4] + ".ttf"
    elif name.endswith(".ttf"):
        alt = name[:-4] + ".otf"
    else:
        alt = None
    if alt:
        alt_path = os.path.join(ASSETS, "fonts", alt)
        if os.path.exists(alt_path):
            return pygame.font.Font(alt_path, size)
    return pygame.font.SysFont("arial", size, bold=True)


FONT_FILE     = "FatPix-SVG.otf"
TUTORIAL_FONT = "DaintyCute.otf"

UI_MAIN   = (255, 215, 140)
UI_SHADOW = (110, 55, 30)
UI_ORANGE = (255, 155, 120)

MAX_LIVES = 3

# --- Playing field bounds (from the background art) ---
FIELD_LEFT   = 88
FIELD_TOP    = 51
FIELD_RIGHT  = 572
FIELD_BOTTOM = 441


class PongScene(Scene):
    KEY = "pong"

    # --- Ball speed ramp (softer to match smaller field) ---
    SPEED_STEP = 0.08
    MAX_SPEED  = 1.9

    # --- AI paddle (fixed speed) ---
    AI_SPEED = 180

    def __init__(self, manager):
        super().__init__(manager)
        self.screen_w, self.screen_h = 640, 480

        # Fonts
        self.ui_font   = load_font(FONT_FILE, 24)
        self.ui_medium = load_font(FONT_FILE, 20)
        self.ui_large  = load_font(FONT_FILE, 34)

        self.tut_font  = load_font(TUTORIAL_FONT, 26)
        self.tut_body  = load_font(TUTORIAL_FONT, 20)
        self.tut_small = load_font(TUTORIAL_FONT, 18)

        # Background
        self.bg = load_image(
            asset("sprites", "pong_bg.png"),
            (self.screen_w, self.screen_h),
            fallback_color=(15, 18, 30)
        )

        # Paddles
        self.player_img = load_image(
            asset("sprites", "salmon_maki.png"),
            (14, 82),
            fallback_color=(240, 140, 100)
        )
        self.ai_img = load_image(
            asset("sprites", "tuna_maki.png"),
            (14, 82),
            fallback_color=(200, 60, 60)
        )

        # Ball
        self.ball_img = load_image(
            asset("sprites", "onigiri.png"),
            (18, 19),
            fallback_color=(245, 240, 220)
        )

        # Heart
        self.heart = load_image(
            asset("sprites", "heart.png"),
            (24, 24),
            fallback_color=(220, 60, 60)
        )
        self.heart_has_sprite = os.path.exists(
            asset("sprites", "heart.png")
        )

        self._tutorial_shown = False
        self.reset()

    # ------------------------------------------------------------------
    def reset(self):
        # Paddles inside the field
        paddle_h = 82
        mid_y = (FIELD_TOP + FIELD_BOTTOM) // 2 - paddle_h // 2
        self.player = pygame.Rect(FIELD_LEFT + 8, mid_y, 14, paddle_h)
        self.ai     = pygame.Rect(FIELD_RIGHT - 22, mid_y, 14, paddle_h)

        # Ball centered in the field
        ball_w, ball_h = 18, 19
        cx = (FIELD_LEFT + FIELD_RIGHT) // 2
        cy = (FIELD_TOP + FIELD_BOTTOM) // 2
        self.ball = pygame.Rect(cx - ball_w // 2, cy - ball_h // 2,
                                ball_w, ball_h)

        self.ball_vx = 240
        self.ball_vy = random.choice([-150, -110, 110, 150])
        self.speed_mult = 1.0

        # Rotation
        self.ball_angle = 0.0
        self.rotation_speed = 30.0

        self.player_lives = MAX_LIVES
        self.ai_lives     = MAX_LIVES

        self.won = False
        self.lost = False
        self.started = self._tutorial_shown

    # ------------------------------------------------------------------
    def _admin_combo(self):
        keys = pygame.key.get_pressed()
        return (keys[pygame.K_LCTRL] and
                keys[pygame.K_LSHIFT] and
                keys[pygame.K_k])

    # ------------------------------------------------------------------
    def handle_event(self, event):
        # Tutorial gate
        if not self._tutorial_shown:
            if (event.type == pygame.KEYDOWN or
                    (event.type == pygame.MOUSEBUTTONDOWN
                     and event.button == 1)):
                self._tutorial_shown = True
                self.started = True
            return

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_k and self._admin_combo():
                self._complete()
                self.won = True
                self.lost = False
                return

            if event.key == pygame.K_ESCAPE:
                self._leave()
            elif event.key == pygame.K_r and (self.won or self.lost):
                self.reset()

        elif event.type == pygame.MOUSEBUTTONDOWN:
            if (self.won or self.lost) and event.button == 1:
                self._leave()
                return
            if (self.won or self.lost) and event.button == 3:
                self.reset()
                return

    # ------------------------------------------------------------------
    def update(self, dt):
        if self.won or self.lost or not self.started:
            return

        keys = pygame.key.get_pressed()

        # --- Player paddle ---
        if keys[pygame.K_UP]:
            self.player.y -= 420 * dt
        if keys[pygame.K_DOWN]:
            self.player.y += 420 * dt
        self.player.clamp_ip(pygame.Rect(
            FIELD_LEFT, FIELD_TOP,
            FIELD_RIGHT - FIELD_LEFT,
            FIELD_BOTTOM - FIELD_TOP
        ))

        # --- AI paddle ---
        target = self.ball.centery - self.ai.height // 2
        diff = target - self.ai.y
        ai_speed = self.AI_SPEED * dt
        if abs(diff) > 4:
            self.ai.y += ai_speed if diff > 0 else -ai_speed
        self.ai.clamp_ip(pygame.Rect(
            FIELD_LEFT, FIELD_TOP,
            FIELD_RIGHT - FIELD_LEFT,
            FIELD_BOTTOM - FIELD_TOP
        ))

        # --- Ball movement ---
        self.ball.x += self.ball_vx * self.speed_mult * dt
        self.ball.y += self.ball_vy * self.speed_mult * dt

        # --- Rotation ---
        self.ball_angle += self.rotation_speed * self.speed_mult * dt
        self.ball_angle %= 360

        # Top / bottom wall collision
        if self.ball.top <= FIELD_TOP:
            self.ball.top = FIELD_TOP
            self.ball_vy *= -1
        if self.ball.bottom >= FIELD_BOTTOM:
            self.ball.bottom = FIELD_BOTTOM
            self.ball_vy *= -1

        # Paddle collisions
        if self.ball.colliderect(self.player) and self.ball_vx < 0:
            self.ball_vx *= -1
            self.ball.x = self.player.right + 1
            self.speed_mult = min(self.speed_mult + self.SPEED_STEP,
                                  self.MAX_SPEED)
            offset = (self.ball.centery - self.player.centery) / (self.player.height / 2)
            self.ball_vy = 180 * offset
        if self.ball.colliderect(self.ai) and self.ball_vx > 0:
            self.ball_vx *= -1
            self.ball.x = self.ai.left - self.ball.width - 1
            self.speed_mult = min(self.speed_mult + self.SPEED_STEP,
                                  self.MAX_SPEED)
            offset = (self.ball.centery - self.ai.centery) / (self.ai.height / 2)
            self.ball_vy = 180 * offset

        # Scoring — missing the ball costs a life
        if self.ball.right < FIELD_LEFT:
            self.player_lives -= 1
            if self.player_lives <= 0:
                self.lost = True
                return
            self._serve(direction=1)
        elif self.ball.left > FIELD_RIGHT:
            self.ai_lives -= 1
            if self.ai_lives <= 0:
                self.won = True
                self._complete()
                return
            self._serve(direction=-1)

    # ------------------------------------------------------------------
    def _serve(self, direction):
        cx = (FIELD_LEFT + FIELD_RIGHT) // 2
        cy = (FIELD_TOP + FIELD_BOTTOM) // 2
        self.ball.center = (cx, cy)
        self.ball_vx = 240 * direction
        self.ball_vy = random.choice([-150, -110, 110, 150])
        self.speed_mult = 1.0

    # ------------------------------------------------------------------
    def _complete(self):
        if self.KEY not in self.manager.progress["completed"]:
            self.manager.progress["completed"].append(self.KEY)

    def _leave(self):
        from scenes.hub import HubScene
        self.manager.go_to(lambda: HubScene(self.manager))

    # ------------------------------------------------------------------
    def _draw_ui_text_center(self, screen, font, text, cx, y,
                             main=UI_MAIN, shadow=UI_SHADOW):
        main_surf = font.render(text, False, main)
        shadow_surf = font.render(text, False, shadow)
        x = cx - main_surf.get_width() // 2
        screen.blit(shadow_surf, (x + 2, y + 2))
        screen.blit(main_surf,   (x,     y))

    def _draw_hearts(self, screen, count, x, y):
        for i in range(MAX_LIVES):
            hx = x + i * 30
            if i < count:
                if self.heart_has_sprite:
                    screen.blit(self.heart, (hx, y))
                else:
                    pygame.draw.circle(screen, (220, 60, 60),
                                       (hx + 12, y + 12), 10)
            else:
                if self.heart_has_sprite:
                    dim = self.heart.copy()
                    dim.fill((60, 40, 40, 200),
                             special_flags=pygame.BLEND_RGBA_MULT)
                    screen.blit(dim, (hx, y))
                else:
                    pygame.draw.circle(screen, (60, 40, 40),
                                       (hx + 12, y + 12), 10)

    # ------------------------------------------------------------------
    def draw(self, screen):
        screen.blit(self.bg, (0, 0))

        # --- Title centered above the middle line ---
        title_surf   = self.ui_font.render("Pong", False, UI_MAIN)
        title_shadow = self.ui_font.render("Pong", False, UI_SHADOW)
        title_x = 320 - title_surf.get_width() // 2
        screen.blit(title_shadow, (title_x + 2, 14))
        screen.blit(title_surf,   (title_x,     12))

        # --- Hearts in the top corners, above the field ---
        # Left corner: player hearts
        self._draw_hearts(screen, self.player_lives, 14, 14)
        # Right corner: AI hearts (end-aligned to the right edge)
        ai_hx = 640 - 14 - 3 * 30 + 6
        self._draw_hearts(screen, self.ai_lives, ai_hx, 14)

        # Paddles
        screen.blit(self.player_img, self.player.topleft)
        screen.blit(self.ai_img, self.ai.topleft)

        # Ball (rotated)
        if self.started and not self.won and not self.lost:
            rotated = pygame.transform.rotate(self.ball_img, -self.ball_angle)
            rot_rect = rotated.get_rect(center=self.ball.center)
            screen.blit(rotated, rot_rect.topleft)

        # Tutorial overlay
        if not self._tutorial_shown:
            self._draw_intro(screen)
            return

        # End states
        if self.won:
            self._draw_ui_text_center(
                screen, self.ui_large, "YOU WIN!",
                320, 195, main=UI_ORANGE, shadow=UI_SHADOW
            )
            self._draw_ui_text_center(
                screen, self.ui_medium,
                "Click or press ESC to return to the hub",
                320, 255
            )
            self._draw_ui_text_center(
                screen, self.ui_medium,
                "Press R to replay",
                320, 285
            )
        elif self.lost:
            self._draw_ui_text_center(
                screen, self.ui_large, "GAME OVER",
                320, 195, main=UI_ORANGE, shadow=UI_SHADOW
            )
            self._draw_ui_text_center(
                screen, self.ui_medium,
                "Click or press ESC to return to the hub",
                320, 255
            )
            self._draw_ui_text_center(
                screen, self.ui_medium,
                "Press R to retry",
                320, 285
            )

    # ------------------------------------------------------------------
    def _draw_intro(self, screen):
        overlay = pygame.Surface((640, 480), pygame.SRCALPHA)
        overlay.fill((60, 30, 20, 140))
        screen.blit(overlay, (0, 0))

        panel = pygame.Rect(100, 90, 440, 320)
        pygame.draw.rect(screen, (245, 230, 200), panel, border_radius=18)
        pygame.draw.rect(screen, (150, 90, 60), panel, 4, border_radius=18)

        title = self.tut_font.render("HOW TO PLAY", True, (150, 70, 50))
        screen.blit(title, (320 - title.get_width() // 2, 110))

        # Mini pong icon
        icon_cy = 200
        pygame.draw.rect(screen, (240, 140, 100),
                         (240, icon_cy - 20, 8, 40))
        pygame.draw.rect(screen, (150, 90, 60),
                         (240, icon_cy - 20, 8, 40), 1)
        pygame.draw.rect(screen, (200, 60, 60),
                         (392, icon_cy - 20, 8, 40))
        pygame.draw.rect(screen, (150, 90, 60),
                         (392, icon_cy - 20, 8, 40), 1)
        pygame.draw.circle(screen, (245, 240, 220), (320, icon_cy), 6)
        pygame.draw.circle(screen, (150, 90, 60), (320, icon_cy), 6, 1)

        lines = [
            "Move with the up and down arrow keys.",
            "Do not let the ball past your paddle.",
            "You have three hearts. Miss the ball to lose one.",
        ]
        y = 260
        for line in lines:
            surf = self.tut_body.render(line, True, (90, 55, 40))
            screen.blit(surf, (320 - surf.get_width() // 2, y))
            y += 30

        hint_text = "Press any arrow key to begin"
        hint_surf = self.tut_small.render(hint_text, True, (180, 80, 60))
        hint_x = 320 - hint_surf.get_width() // 2
        hint_y = panel.bottom - 40
        pad = 8
        hint_bg = pygame.Rect(
            hint_x - pad, hint_y - pad // 2,
            hint_surf.get_width() + pad * 2,
            hint_surf.get_height() + pad
        )
        pygame.draw.rect(screen, (250, 220, 195), hint_bg, border_radius=8)
        screen.blit(hint_surf, (hint_x, hint_y))
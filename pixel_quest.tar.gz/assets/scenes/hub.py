import os
import pygame
from scenes.base_scene import Scene

ASSETS = "assets"
def asset(*parts):
    return os.path.join(ASSETS, *parts)


def load_image(path, size, fallback_color=None):
    if os.path.exists(path):
        img = pygame.image.load(path).convert_alpha()
        return pygame.transform.scale(img, size)
    surf = pygame.Surface(size, pygame.SRCALPHA)
    if fallback_color:
        surf.fill(fallback_color)
    return surf


def load_font(name, size):
    path = os.path.join(ASSETS, "fonts", name)
    if os.path.exists(path):
        return pygame.font.Font(path, size)
    return pygame.font.SysFont("arial", size, bold=True)


def bounding_box(mask, alpha_threshold=10):
    w, h = mask.get_size()
    min_x, min_y = w, h
    max_x, max_y = -1, -1
    for y in range(h):
        for x in range(w):
            if mask.get_at((x, y))[3] > alpha_threshold:
                if x < min_x: min_x = x
                if y < min_y: min_y = y
                if x > max_x: max_x = x
                if y > max_y: max_y = y
    if max_x < 0:
        return None
    return (min_x, min_y, max_x - min_x + 1, max_y - min_y + 1)


def dilate_mask(mask):
    w, h = mask.get_size()
    new = pygame.mask.Mask((w, h))
    new.draw(mask, (0, 0))
    for x in range(w):
        for y in range(h):
            if mask.get_at((x, y)):
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < w and 0 <= ny < h:
                            new.set_at((nx, ny), 1)
    return new


def render_text_with_outline(font, text, main_color, shadow_color,
                             outline_color, outline_thickness=2,
                             shadow_offset=1):
    main = font.render(text, False, main_color)
    shadow = font.render(text, False, shadow_color)

    t = outline_thickness
    pad = t + shadow_offset + 2

    w = main.get_width() + pad * 2
    h = main.get_height() + pad * 2
    surf = pygame.Surface((w, h), pygame.SRCALPHA)

    base_x = pad
    base_y = pad

    mask = pygame.mask.from_surface(main)
    expanded = mask
    for _ in range(t):
        expanded = dilate_mask(expanded)
    outline_surf = expanded.to_surface(
        setcolor=outline_color,
        unsetcolor=(0, 0, 0, 0)
    )

    surf.blit(shadow, (base_x + shadow_offset, base_y + shadow_offset))
    surf.blit(outline_surf, (base_x - t, base_y - t))
    surf.blit(main, (base_x, base_y))

    return surf


GATE_ORDER = ["snake", "pong", "sudoku", "memory"]


class Gate:
    def __init__(self, x, y, key, size):
        self.key = key
        self.rect = pygame.Rect(x, y, size[0], size[1])
        self.hover = False


class HubScene(Scene):
    # --- Colors ---
    TITLE_MAIN   = (255, 155, 120)
    TITLE_SHADOW = (140, 60, 45)
    LOCK_MAIN    = (230, 90, 90)
    LOCK_SHADOW  = (90, 30, 30)
    OUTLINE      = (255, 255, 255)

    # --- Glow ---
    GLOW_COLOR        = (255, 220, 150)
    GLOW_MIN          = 25
    GLOW_MAX          = 65
    GLOW_SPEED        = 150
    GLOW_ALPHA_FACTOR = 0.55

    # --- Click padding ---
    HIT_PADDING = 6

    def __init__(self, manager):
        super().__init__(manager)
        self.screen_w, self.screen_h = 640, 480

        self.font       = load_font("FatPix-SVG.otf", 20)
        self.small_font = load_font("FatPix-SVG.otf", 12)
        self.tiny_font  = load_font("FatPix-SVG.otf", 10)

        self.bg = load_image(
            asset("sprites", "hub_bg.png"),
            (self.screen_w, self.screen_h),
            fallback_color=(255, 210, 200)
        )

        self._gate_cache = {}

        # Load masks (raw)
        self.masks = {}
        for key in list(GATE_ORDER) + ["end"]:
            path = asset("sprites", f"{key}_mask.png")
            if os.path.exists(path):
                img = pygame.image.load(path).convert_alpha()
                img = pygame.transform.scale(
                    img, (self.screen_w, self.screen_h)
                )
                self.masks[key] = img
            else:
                self.masks[key] = None

        # Gates from mask bounding boxes
        self.gates = []
        for key in GATE_ORDER:
            rect = self._mask_rect(key)
            if rect is None:
                rect = pygame.Rect(0, 0, 60, 60)
            self.gates.append(Gate(rect.x, rect.y, key,
                                   (rect.width, rect.height)))

        end_rect = self._mask_rect("end")
        if end_rect is None:
            end_rect = pygame.Rect(0, 0, 60, 60)
        self.end_gate = Gate(end_rect.x, end_rect.y, "end",
                             (end_rect.width, end_rect.height))

        # Back arrow
        self.back_img = load_image(
            asset("sprites", "back_arrow.png"),
            (56, 56),
            fallback_color=None
        )
        self.back_has_sprite = os.path.exists(
            asset("sprites", "back_arrow.png")
        )
        self.back_rect = pygame.Rect(0, 0, 56, 56)
        self.back_rect.center = (self.screen_w // 2, 442)
        self.back_hover = False

        if self.back_has_sprite:
            self.back_img_rotated = pygame.transform.rotate(self.back_img, -8)
        else:
            self.back_img_rotated = None
        # Checkmark (drawn over completed games)
        self.check_img = load_image(
            asset("sprites", "checkmark.png"),
            (48, 48),
            fallback_color=None
        )
        self.check_has_sprite = os.path.exists(
            asset("sprites", "checkmark.png")
        )
        # --- Lock (drawn over the end door when it's still locked) ---
        self.lock_img = load_image(
            asset("sprites", "lock.png"),
            (64, 64),
            fallback_color=None
        )
        self.lock_has_sprite = os.path.exists(
            asset("sprites", "lock.png")
        )

        self.t = 0.0

    # ------------------------------------------------------------------
    def _mask_rect(self, key):
        mask = self.masks.get(key)
        if mask is None:
            return None
        box = bounding_box(mask)
        if box is None:
            return None
        x, y, w, h = box
        r = pygame.Rect(x, y, w, h)
        r.inflate_ip(self.HIT_PADDING * 2, self.HIT_PADDING * 2)
        return r

    # ------------------------------------------------------------------
    def _get_gate_image(self, key, state):
        cache_key = (key, state)
        if cache_key in self._gate_cache:
            return self._gate_cache[cache_key]

        mask_rect = self._mask_rect(key)
        size = (mask_rect.width, mask_rect.height) if mask_rect else (60, 60)

        candidates = [
            asset("sprites", f"{key}_gate_{state}.png"),
            asset("sprites", f"gate_{state}.png"),
        ]
        img = None
        for path in candidates:
            if os.path.exists(path):
                img = pygame.transform.scale(
                    pygame.image.load(path).convert_alpha(), size
                )
                break
        if img is None:
            img = pygame.Surface(size, pygame.SRCALPHA)

        self._gate_cache[cache_key] = img
        return img

    def _get_end_image(self, unlocked):
        state = "unlocked" if unlocked else "locked"
        cache_key = ("end", state)
        if cache_key in self._gate_cache:
            return self._gate_cache[cache_key]

        mask_rect = self._mask_rect("end")
        size = (mask_rect.width, mask_rect.height) if mask_rect else (60, 60)

        candidates = [
            asset("sprites", f"end_gate_{state}.png"),
            asset("sprites", "end_gate.png"),
        ]
        img = None
        for path in candidates:
            if os.path.exists(path):
                img = pygame.transform.scale(
                    pygame.image.load(path).convert_alpha(), size
                )
                break
        if img is None:
            img = pygame.Surface(size, pygame.SRCALPHA)

        self._gate_cache[cache_key] = img
        return img

    # ------------------------------------------------------------------
    def is_unlocked(self, key):
        # All minigames are always unlocked.
        return True

    def is_done(self, key):
        return key in self.manager.progress["completed"]

    def all_done(self):
        return all(self.is_done(k) for k in GATE_ORDER)

    def gate_state(self, key):
        if self.is_done(key):
            return "done"
        if self.is_unlocked(key):
            return "unlocked"
        return "locked"

    # ------------------------------------------------------------------
    def _arrow_float_offset(self):
        return int(4 * pygame.math.Vector2(1, 0).rotate(self.t * 90).y)

    def _arrow_hit_rect(self):
        return self.back_rect.move(0, self._arrow_float_offset())

    # ------------------------------------------------------------------
    def _draw_hover_mask(self, screen, key):
        mask = self.masks.get(key)
        if mask is None:
            return

        pulse = 0.5 + 0.5 * pygame.math.Vector2(1, 0).rotate(
            self.t * self.GLOW_SPEED
        ).x
        strength = int(self.GLOW_MIN + (self.GLOW_MAX - self.GLOW_MIN) * pulse)
        strength = max(0, min(255, strength))

        final_alpha = int(strength * self.GLOW_ALPHA_FACTOR)
        final_alpha = max(0, min(255, final_alpha))

        tinted = mask.copy()
        tinted.fill(
            (*self.GLOW_COLOR, 255),
            special_flags=pygame.BLEND_RGBA_MULT
        )
        tinted.fill(
            (255, 255, 255, final_alpha),
            special_flags=pygame.BLEND_RGBA_MULT
        )

        screen.blit(tinted, (0, 0), special_flags=pygame.BLEND_RGBA_ADD)

    # ------------------------------------------------------------------
    def _draw_text_with_shadow(self, screen, font, text, center,
                               main_color, shadow_color, offset=1,
                               outline_color=(255, 255, 255),
                               outline_thickness=2):
        surf = render_text_with_outline(
            font, text, main_color, shadow_color,
            outline_color, outline_thickness, offset
        )
        rect = surf.get_rect(center=center)
        screen.blit(surf, rect.topleft)

    # ------------------------------------------------------------------
    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            for g in self.gates:
                g.hover = (g.rect.collidepoint(event.pos)
                           and self.is_unlocked(g.key))
            self.end_gate.hover = (self.end_gate.rect.collidepoint(event.pos)
                                   and self.all_done())
            self.back_hover = self._arrow_hit_rect().collidepoint(event.pos)

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self._arrow_hit_rect().collidepoint(event.pos):
                self._back_to_title()
                return
            for g in self.gates:
                if g.rect.collidepoint(event.pos) and self.is_unlocked(g.key):
                    self._open_gate(g.key)
                    return
            if (self.end_gate.rect.collidepoint(event.pos)
                    and self.all_done()):
                self._open_end()
                return

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_k and self._admin_combo():
                for k in GATE_ORDER:
                    if k not in self.manager.progress["completed"]:
                        self.manager.progress["completed"].append(k)
                return
            if event.key == pygame.K_1 and self.is_unlocked("snake"):
                self._open_gate("snake")
            elif event.key == pygame.K_2 and self.is_unlocked("pong"):
                self._open_gate("pong")
            elif event.key == pygame.K_3 and self.is_unlocked("sudoku"):
                self._open_gate("sudoku")
            elif event.key == pygame.K_4 and self.is_unlocked("memory"):
                self._open_gate("memory")
            elif event.key == pygame.K_e and self.all_done():
                self._open_end()
            elif event.key == pygame.K_ESCAPE:
                self._back_to_title()

    def _admin_combo(self):
        keys = pygame.key.get_pressed()
        return (keys[pygame.K_LCTRL] and
                keys[pygame.K_LSHIFT] and
                keys[pygame.K_k])

    # ------------------------------------------------------------------
    def _open_gate(self, key):
        if key == "snake":
            from scenes.game1_snake import SnakeScene
            self.manager.go_to(SnakeScene(self.manager))
        elif key == "pong":
            from scenes.game2_pong import PongScene
            self.manager.go_to(PongScene(self.manager))
        elif key == "sudoku":
            from scenes.game3_sudoku import SudokuScene
            self.manager.go_to(SudokuScene(self.manager))
        elif key == "memory":
            from scenes.game4_memory import MemoryScene
            self.manager.go_to(MemoryScene(self.manager))

    def _open_end(self):
        self.manager._letter_was_read = False
        from scenes.quiz import QuizScene
        self.manager.go_to(QuizScene(self.manager))

    def _back_to_title(self):
        from scenes.start import StartScene
        self.manager.go_to(StartScene(self.manager))

    # ------------------------------------------------------------------
    def update(self, dt):
        self.t += dt

    # ------------------------------------------------------------------
    def draw(self, screen):
        screen.blit(self.bg, (0, 0))

        # Title
        title = self.font.render("Choose a Gate", False, (255, 155, 120))
        title_shadow = self.font.render("Choose a Gate", False, (140, 60, 45))
        tx = self.screen_w // 2 - title.get_width() // 2
        screen.blit(title_shadow, (tx + 2, 16))
        screen.blit(title, (tx, 14))

        # Progress — bigger, with shadow, cream and brown
        done_count = sum(1 for k in GATE_ORDER if self.is_done(k))
        sub_text = f"{done_count} / {len(GATE_ORDER)} games completed"
        sub_surf = self.small_font.render(sub_text, False, (255, 215, 140))
        sub_shadow = self.small_font.render(sub_text, False, (110, 55, 30))
        sub_x = self.screen_w // 2 - sub_surf.get_width() // 2
        screen.blit(sub_shadow, (sub_x + 2, 52))
        screen.blit(sub_surf,   (sub_x,     50))
        
        # Gates
        for g in self.gates:
            state = self.gate_state(g.key)
            img = self._get_gate_image(g.key, state)

            bob = int(3 * pygame.math.Vector2(1, 0).rotate(self.t * 100).y) \
                  if state != "locked" else 0

            screen.blit(img, (g.rect.x, g.rect.y + bob))

            if g.hover:
                self._draw_hover_mask(screen, g.key)

            # Green pixel checkmark over completed games
            if state == "done":
                check_center = (g.rect.centerx, g.rect.centery + bob)
                self._draw_checkmark(screen, check_center)

        # End gate
        e = self.end_gate
        end_img = self._get_end_image(self.all_done())

        bob = int(4 * pygame.math.Vector2(1, 0).rotate(self.t * 100).y) \
              if self.all_done() else 0

        screen.blit(end_img, (e.rect.x, e.rect.y + bob))

        if e.hover:
            self._draw_hover_mask(screen, "end")

        # Only the END door shows a LOCKED label
        if not self.all_done():
            if self.lock_has_sprite:
                lock_rect = self.lock_img.get_rect(
                    center=(e.rect.centerx, e.rect.centery + bob)
                )
                screen.blit(self.lock_img, lock_rect.topleft)
            else:
                # Fallback: text label if no sprite is present
                self._draw_text_with_shadow(
                    screen, self.small_font, "LOCKED",
                    (e.rect.centerx, e.rect.centery),
                    self.LOCK_MAIN, self.LOCK_SHADOW,
                    offset=1, outline_color=self.OUTLINE,
                    outline_thickness=0
                )

        self._draw_back_arrow(screen)

    # ------------------------------------------------------------------
    def _draw_back_arrow(self, screen):
        rect = self.back_rect
        float_y = self._arrow_float_offset()
        draw_rect = rect.move(0, float_y)

        # If a sprite exists, use it
        if self.back_has_sprite:
            img = self.back_img_rotated
            if self.back_hover:
                img = img.copy()
                img.fill((50, 50, 50, 70),
                         special_flags=pygame.BLEND_RGBA_ADD)
            img_rect = img.get_rect(center=draw_rect.center)
            screen.blit(img, img_rect.topleft)
            return

        # ---- Fallback: pixel-art wooden V ----
        # Everything is drawn on a chunky pixel grid so it matches
        # the blocky feel of the room.
        PIXEL = 4                 # size of one "pixel" in the V
        cols  = 20                # V is 20 pixels wide
        rows  = 8                 # V is 8 pixels tall

        w = cols * PIXEL
        h = rows * PIXEL

        origin_x = draw_rect.centerx - w // 2
        origin_y = draw_rect.centery - h // 2

        # Wood palette
        wood_main   = (170, 110, 70)     # mid wood
        wood_light  = (220, 165, 110)    # highlight
        wood_dark   = (110, 60, 40)      # shadow
        wood_outln  = (80, 40, 25)       # outline

        # A pixel map: 0 = empty, 1 = wood mid, 2 = light, 3 = dark
        # Wide V shape, pointing down
        pixel_map = [
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 2, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 2, 2, 0],
            [0, 1, 1, 1, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 3, 2, 1, 1, 1, 0],
            [0, 0, 1, 1, 1, 1, 2, 3, 0, 0, 0, 0, 3, 2, 1, 1, 1, 1, 0, 0],
            [0, 0, 0, 1, 1, 1, 1, 1, 2, 3, 3, 2, 1, 1, 1, 1, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0],
        ]

        color_for = {
            1: wood_main,
            2: wood_light,
            3: wood_dark,
        }

        for row in range(rows):
            for col in range(cols):
                code = pixel_map[row][col]
                if code == 0:
                    continue
                px = origin_x + col * PIXEL
                py = origin_y + row * PIXEL
                pygame.draw.rect(
                    screen, color_for[code],
                    (px, py, PIXEL, PIXEL)
                )

        # Dark outline — draw a 2px border on any edge that touches
        # empty space. Checking all 8 neighbours catches corners cleanly.
        border_thickness = 2

        def is_empty(c, r):
            return (c < 0 or c >= cols or r < 0 or r >= rows or
                    pixel_map[r][c] == 0)

        for row in range(rows):
            for col in range(cols):
                if pixel_map[row][col] == 0:
                    continue

                px = origin_x + col * PIXEL
                py = origin_y + row * PIXEL

                # Left edge
                if is_empty(col - 1, row):
                    pygame.draw.rect(
                        screen, wood_outln,
                        (px, py, border_thickness, PIXEL)
                    )
                # Right edge
                if is_empty(col + 1, row):
                    pygame.draw.rect(
                        screen, wood_outln,
                        (px + PIXEL - border_thickness, py,
                         border_thickness, PIXEL)
                    )
                # Top edge
                if is_empty(col, row - 1):
                    pygame.draw.rect(
                        screen, wood_outln,
                        (px, py, PIXEL, border_thickness)
                    )
                # Bottom edge
                if is_empty(col, row + 1):
                    pygame.draw.rect(
                        screen, wood_outln,
                        (px, py + PIXEL - border_thickness,
                         PIXEL, border_thickness)
                    )
    def _draw_checkmark(self, screen, center):
        """Draw a pixel-art green checkmark centered at `center`."""
        if self.check_has_sprite:
            img_rect = self.check_img.get_rect(center=center)
            screen.blit(self.check_img, img_rect.topleft)
            return

        # ---- Fallback: hand-drawn pixel checkmark ----
        PIXEL = 2                    # size of one pixel

        # Colors from your reference image
        dark    = (40, 45, 70)     # outline
        mid     = (110, 200, 120)  # main green
        light   = (200, 240, 140)  # highlight
        shadow  = (60, 140, 90)    # darker green (bottom-right shading)

        # Pixel map:
        #   0 = empty
        #   1 = mid green (body)
        #   2 = highlight (upper-left)
        #   3 = shadow (lower-right)
        pixel_map = [
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 2, 2, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 2, 2, 2, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 2, 2, 2, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 2, 2, 2, 0, 0, 0],
            [0, 3, 3, 0, 0, 0, 0, 0, 0, 0, 3, 2, 2, 2, 0, 0, 0, 0],
            [3, 2, 2, 3, 0, 0, 0, 0, 0, 3, 2, 2, 2, 0, 0, 0, 0, 0],
            [0, 3, 2, 2, 3, 0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0, 0],
            [0, 0, 3, 2, 2, 3, 0, 0, 2, 2, 2, 3, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 3, 2, 2, 3, 2, 2, 2, 3, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 3, 2, 2, 2, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 3, 2, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        ]

        rows = len(pixel_map)
        cols = len(pixel_map[0])
        w = cols * PIXEL
        h = rows * PIXEL

        origin_x = center[0] - w // 2
        origin_y = center[1] - h // 2

        color_for = {
            1: mid,
            2: light,
            3: shadow,
        }

        # Draw the body
        for row in range(rows):
            for col in range(cols):
                code = pixel_map[row][col]
                if code == 0:
                    continue
                px = origin_x + col * PIXEL
                py = origin_y + row * PIXEL
                pygame.draw.rect(
                    screen, color_for[code],
                    (px, py, PIXEL, PIXEL)
                )

        # Dark outline — 1px border on edges touching empty space
        def is_empty(c, r):
            return (c < 0 or c >= cols or r < 0 or r >= rows or
                    pixel_map[r][c] == 0)

        for row in range(rows):
            for col in range(cols):
                if pixel_map[row][col] == 0:
                    continue
                px = origin_x + col * PIXEL
                py = origin_y + row * PIXEL
                if is_empty(col - 1, row):
                    pygame.draw.rect(screen, dark,
                                     (px, py, 1, PIXEL))
                if is_empty(col + 1, row):
                    pygame.draw.rect(screen, dark,
                                     (px + PIXEL - 1, py, 1, PIXEL))
                if is_empty(col, row - 1):
                    pygame.draw.rect(screen, dark,
                                     (px, py, PIXEL, 1))
                if is_empty(col, row + 1):
                    pygame.draw.rect(screen, dark,
                                     (px, py + PIXEL - 1, PIXEL, 1))
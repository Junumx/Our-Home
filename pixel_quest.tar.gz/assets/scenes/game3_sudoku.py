import os
import random
from copy import deepcopy
import pygame
from scenes.base_scene import Scene

ASSETS = "assets"
def asset(*parts):
    return os.path.join(ASSETS, *parts)


def load_image(path, size, fallback_color=None):
    if os.path.exists(path):
        img = pygame.image.load(path).convert_alpha()
        return pygame.transform.scale(img, size)
    surf = pygame.Surface(size, pygame.SRCALPHA)
    if fallback_color:
        surf.fill(fallback_color)
    return surf


def load_font(name, size):
    path = os.path.join(ASSETS, "fonts", name)
    if os.path.exists(path):
        return pygame.font.Font(path, size)
    if name.endswith(".otf"):
        alt = name[:-4] + ".ttf"
    elif name.endswith(".ttf"):
        alt = name[:-4] + ".otf"
    else:
        alt = None
    if alt:
        alt_path = os.path.join(ASSETS, "fonts", alt)
        if os.path.exists(alt_path):
            return pygame.font.Font(alt_path, size)
    return pygame.font.SysFont("arial", size, bold=True)


# ==================================================================
# Sudoku generator + solver
# ==================================================================

def _find_empty(grid):
    for r in range(9):
        for c in range(9):
            if grid[r][c] == 0:
                return r, c
    return None


def _is_safe(grid, r, c, v):
    for i in range(9):
        if grid[r][i] == v: return False
        if grid[i][c] == v: return False
    br, bc = (r // 3) * 3, (c // 3) * 3
    for i in range(br, br + 3):
        for j in range(bc, bc + 3):
            if grid[i][j] == v: return False
    return True


def _fill_grid(grid):
    spot = _find_empty(grid)
    if spot is None:
        return True
    r, c = spot
    nums = list(range(1, 10))
    random.shuffle(nums)
    for v in nums:
        if _is_safe(grid, r, c, v):
            grid[r][c] = v
            if _fill_grid(grid):
                return True
            grid[r][c] = 0
    return False


def _count_solutions(grid, limit=2):
    spot = _find_empty(grid)
    if spot is None:
        return 1
    r, c = spot
    count = 0
    for v in range(1, 10):
        if _is_safe(grid, r, c, v):
            grid[r][c] = v
            count += _count_solutions(grid, limit)
            grid[r][c] = 0
            if count >= limit:
                return count
    return count


def _candidates(grid, r, c):
    used = set(grid[r])
    used.update(grid[i][c] for i in range(9))
    br, bc = (r // 3) * 3, (c // 3) * 3
    for i in range(br, br + 3):
        for j in range(bc, bc + 3):
            used.add(grid[i][j])
    return {v for v in range(1, 10) if v not in used}


def _place_naked_singles(grid):
    progress = False
    for r in range(9):
        for c in range(9):
            if grid[r][c] == 0:
                cands = _candidates(grid, r, c)
                if len(cands) == 1:
                    grid[r][c] = cands.pop()
                    progress = True
    return progress


def _place_hidden_singles(grid):
    progress = False
    for r in range(9):
        for v in range(1, 10):
            if v in grid[r]:
                continue
            spots = [c for c in range(9)
                     if grid[r][c] == 0 and v in _candidates(grid, r, c)]
            if len(spots) == 1:
                grid[r][spots[0]] = v
                progress = True
    for c in range(9):
        for v in range(1, 10):
            if any(grid[r][c] == v for r in range(9)):
                continue
            spots = [r for r in range(9)
                     if grid[r][c] == 0 and v in _candidates(grid, r, c)]
            if len(spots) == 1:
                grid[spots[0]][c] = v
                progress = True
    for br in range(0, 9, 3):
        for bc in range(0, 9, 3):
            for v in range(1, 10):
                if any(grid[i][j] == v
                       for i in range(br, br + 3)
                       for j in range(bc, bc + 3)):
                    continue
                spots = [(i, j)
                         for i in range(br, br + 3)
                         for j in range(bc, bc + 3)
                         if grid[i][j] == 0
                         and v in _candidates(grid, i, j)]
                if len(spots) == 1:
                    i, j = spots[0]
                    grid[i][j] = v
                    progress = True
    return progress


def _solvable_with_basic_techniques(grid):
    work = deepcopy(grid)
    while True:
        if all(work[r][c] != 0 for r in range(9) for c in range(9)):
            return True
        made_progress = False
        if _place_naked_singles(work):
            made_progress = True
        if _place_hidden_singles(work):
            made_progress = True
        if not made_progress:
            return False


def generate_puzzle(clue_target=32, max_attempts=200):
    for _ in range(max_attempts):
        solution = [[0] * 9 for _ in range(9)]
        _fill_grid(solution)
        puzzle = deepcopy(solution)
        cells = [(r, c) for r in range(9) for c in range(9)]
        random.shuffle(cells)
        for (r, c) in cells:
            clues_left = sum(1 for row in puzzle for x in row if x != 0)
            if clues_left <= clue_target:
                break
            removed = puzzle[r][c]
            puzzle[r][c] = 0
            if (_count_solutions(deepcopy(puzzle), limit=2) != 1 or
                    not _solvable_with_basic_techniques(puzzle)):
                puzzle[r][c] = removed
        clues_left = sum(1 for row in puzzle for x in row if x != 0)
        if clues_left <= clue_target:
            return puzzle, solution
    return puzzle, solution


# ==================================================================
# Scene
# ==================================================================

CHINESE_DIGITS = ["一", "二", "三", "四", "五", "六", "七", "八", "九"]


class SudokuScene(Scene):
    KEY = "sudoku"

    CELL = 28
    ORIGIN = (195, 118)

    CLUE_TARGET = 32
    MAX_LIVES = 3

    UI_FONT       = "FatPix-SVG.otf"
    CJK_FONT      = "RenOuFangSong-16.ttf"
    TUTORIAL_FONT = "DaintyCute.otf"

    UI_MAIN   = (255, 215, 140)
    UI_SHADOW = (110, 55, 30)
    UI_ORANGE = (255, 155, 120)

    GIVEN_COLOR   = (40, 30, 25)
    CORRECT_COLOR = (60, 160, 80)
    WRONG_COLOR   = (200, 50, 50)

    SELECT_OUTLINE_COLOR  = (40, 60, 130)
    SELECT_OUTLINE_WIDTH  = 2
    SELECT_OUTLINE_GROWTH = 1

    def __init__(self, manager):
        super().__init__(manager)
        self.screen_w, self.screen_h = 640, 480

        # UI fonts (FatPix)
        self.ui_font   = load_font(self.UI_FONT, 24)
        self.ui_medium = load_font(self.UI_FONT, 20)
        self.ui_large  = load_font(self.UI_FONT, 34)
        self.ui_tiny   = load_font(self.UI_FONT, 12)

        # CJK font for digits
        self.digit_font = load_font(self.CJK_FONT, 22)

        # DaintyCute tutorial fonts
        self.tut_font  = load_font(self.TUTORIAL_FONT, 26)
        self.tut_body  = load_font(self.TUTORIAL_FONT, 20)
        self.tut_small = load_font(self.TUTORIAL_FONT, 18)

        # Tutorial flag (set before new_puzzle so it isn't reset)
        self._tutorial_shown = False

        # Background
        self.bg = load_image(
            asset("sprites", "sudoku_bg.png"),
            (self.screen_w, self.screen_h),
            fallback_color=(245, 230, 200)
        )

        # Heart sprite for lives
        self.heart = load_image(
            asset("sprites", "heart.png"),
            (28, 28),
            fallback_color=(220, 60, 60)
        )
        self.heart_has_sprite = os.path.exists(
            asset("sprites", "heart.png")
        )

        self.new_puzzle()

    # ------------------------------------------------------------------
    def new_puzzle(self):
        self.puzzle, self.solution = generate_puzzle(self.CLUE_TARGET)
        self.FIXED  = {(r, c) for r in range(9) for c in range(9)
                       if self.puzzle[r][c] != 0}
        self.LOCKED = set()
        self.grid = [row[:] for row in self.puzzle]
        self.selected = None
        self.won = False
        self.lost = False
        self.lives = self.MAX_LIVES
        self.error_flash = 0.0
        self.player_marks = {}
        # The tutorial flag is never reset here, so R does not re-show it

    # ------------------------------------------------------------------
    def _digit_count(self, v):
        return sum(1 for r in range(9) for c in range(9)
                   if self.grid[r][c] == v)

    def _is_digit_complete(self, v):
        return self._digit_count(v) >= 9

    # ------------------------------------------------------------------
    def _admin_combo(self):
        keys = pygame.key.get_pressed()
        return (keys[pygame.K_LCTRL] and
                keys[pygame.K_LSHIFT] and
                keys[pygame.K_k])

    # ------------------------------------------------------------------
    def handle_event(self, event):
        # Tutorial gate: any key or click dismisses it; nothing else runs
        if not self._tutorial_shown:
            if (event.type == pygame.KEYDOWN or
                    (event.type == pygame.MOUSEBUTTONDOWN
                     and event.button == 1)):
                self._tutorial_shown = True
            return

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_k and self._admin_combo():
                self._complete()
                self.won = True
                self.lost = False
                return

            if event.key == pygame.K_ESCAPE:
                self._leave()
            elif self.lost and event.key == pygame.K_r:
                self.new_puzzle()
            elif self.won and event.key == pygame.K_r:
                self.new_puzzle()
            elif (not self.won and not self.lost
                  and pygame.K_1 <= event.key <= pygame.K_9):
                v = event.key - pygame.K_0
                self._place(v)
            elif (not self.won and not self.lost
                  and event.key in (pygame.K_BACKSPACE,
                                    pygame.K_DELETE,
                                    pygame.K_0)):
                self._clear()
            elif self.selected is not None and not self.lost and not self.won:
                r, c = self.selected
                if event.key == pygame.K_UP:    self.selected = (max(0, r - 1), c)
                if event.key == pygame.K_DOWN:  self.selected = (min(8, r + 1), c)
                if event.key == pygame.K_LEFT:  self.selected = (r, max(0, c - 1))
                if event.key == pygame.K_RIGHT: self.selected = (r, min(8, c + 1))

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.lost:
                self.new_puzzle()
                return
            if self.won:
                self._leave()
                return
            self.selected = self._cell_at(event.pos)

    def _cell_at(self, pos):
        ox, oy = self.ORIGIN
        x, y = pos

        total = 9 * self.CELL + 6 * 1 + 2 * 2
        if not (ox <= x < ox + total and oy <= y < oy + total):
            return None

        col_idx = self._axis_index(x - ox)
        row_idx = self._axis_index(y - oy)
        if col_idx is None or row_idx is None:
            return None
        return (row_idx, col_idx)

    def _axis_index(self, dist):
        pos = 0
        for cell in range(9):
            if pos <= dist < pos + self.CELL:
                return cell
            pos += self.CELL
            if cell == 2 or cell == 5:
                line_w = 2
            elif cell == 8:
                return None
            else:
                line_w = 1
            if pos <= dist < pos + line_w:
                return None
            pos += line_w
        return None

    # ------------------------------------------------------------------
    def _place(self, value):
        if self.selected is None or self.won or self.lost:
            return
        r, c = self.selected
        if (r, c) in self.FIXED or (r, c) in self.LOCKED:
            return
        if self._is_digit_complete(value):
            return

        replacing = self.grid[r][c] != 0

        if value == self.solution[r][c]:
            self.grid[r][c] = value
            self.LOCKED.add((r, c))
            self.player_marks[(r, c)] = True
            if self._is_solved():
                self.won = True
                self._complete()
        else:
            self.grid[r][c] = value
            self.player_marks[(r, c)] = False
            if not replacing:
                self.lives -= 1
                self.error_flash = 0.6
                if self.lives <= 0:
                    self.lost = True

    def _clear(self):
        if self.selected is None or self.won or self.lost:
            return
        r, c = self.selected
        if (r, c) in self.FIXED or (r, c) in self.LOCKED:
            return
        self.grid[r][c] = 0
        self.player_marks.pop((r, c), None)

    def _is_solved(self):
        return all(self.grid[r][c] != 0 for r in range(9) for c in range(9))

    def _complete(self):
        if self.KEY not in self.manager.progress["completed"]:
            self.manager.progress["completed"].append(self.KEY)

    def _leave(self):
        from scenes.hub import HubScene
        self.manager.go_to(lambda: HubScene(self.manager))

    # ------------------------------------------------------------------
    def update(self, dt):
        if not self._tutorial_shown:
            return
        if self.error_flash > 0:
            self.error_flash -= dt

    # ------------------------------------------------------------------
    def _draw_ui_text_center(self, screen, font, text, cx, y,
                             main=UI_MAIN, shadow=UI_SHADOW):
        main_surf = font.render(text, False, main)
        shadow_surf = font.render(text, False, shadow)
        x = cx - main_surf.get_width() // 2
        screen.blit(shadow_surf, (x + 2, y + 2))
        screen.blit(main_surf,   (x,     y))

    # ------------------------------------------------------------------
    def _cell_offset(self, index):
        offset = 0
        for i in range(index):
            offset += self.CELL
            if i == 2 or i == 5:
                offset += 2
            else:
                offset += 1
        return offset

    # ------------------------------------------------------------------
    def draw(self, screen):
        screen.blit(self.bg, (0, 0))

        # Title top-right
        title_surf  = self.ui_font.render("Sudoku", False, self.UI_MAIN)
        shadow_surf = self.ui_font.render("Sudoku", False, self.UI_SHADOW)
        title_x = self.screen_w - title_surf.get_width() - 20
        screen.blit(shadow_surf, (title_x + 2, 18))
        screen.blit(title_surf,  (title_x,     16))

        # Lives (hearts)
        for i in range(self.MAX_LIVES):
            hx = self.screen_w - 28 - 20 - (self.MAX_LIVES - 1 - i) * 32
            hy = 48
            if i < self.lives:
                if self.heart_has_sprite:
                    screen.blit(self.heart, (hx, hy))
                else:
                    pygame.draw.circle(screen, (220, 60, 60),
                                       (hx + 14, hy + 14), 12)
            else:
                if self.heart_has_sprite:
                    dim = self.heart.copy()
                    dim.fill((60, 40, 40, 200),
                             special_flags=pygame.BLEND_RGBA_MULT)
                    screen.blit(dim, (hx, hy))
                else:
                    pygame.draw.circle(screen, (60, 40, 40),
                                       (hx + 14, hy + 14), 12)

        # Digits
        for r in range(9):
            for c in range(9):
                v = self.grid[r][c]
                if v == 0:
                    continue
                if (r, c) in self.FIXED:
                    color = self.GIVEN_COLOR
                elif (r, c) in self.LOCKED:
                    color = self.CORRECT_COLOR
                elif self.player_marks.get((r, c)) is False:
                    color = self.WRONG_COLOR
                else:
                    color = self.GIVEN_COLOR

                px = self.ORIGIN[0] + self._cell_offset(c)
                py = self.ORIGIN[1] + self._cell_offset(r)
                glyph = CHINESE_DIGITS[v - 1]
                surf = self.digit_font.render(glyph, True, color)
                gx = px + self.CELL // 2 - surf.get_width() // 2
                gy = py + self.CELL // 2 - surf.get_height() // 2
                screen.blit(surf, (gx, gy))

        # Selection outline (dark blue, 2px, grows 1px per side)
        if (self.selected is not None
                and not self.lost and not self.won):
            r, c = self.selected
            if (r, c) not in self.FIXED and (r, c) not in self.LOCKED:
                px = self.ORIGIN[0] + self._cell_offset(c)
                py = self.ORIGIN[1] + self._cell_offset(r)
                g = self.SELECT_OUTLINE_GROWTH
                sel_rect = pygame.Rect(
                    px - g, py - g,
                    self.CELL + 2 * g,
                    self.CELL + 2 * g
                )
                pygame.draw.rect(
                    screen,
                    self.SELECT_OUTLINE_COLOR,
                    sel_rect,
                    self.SELECT_OUTLINE_WIDTH
                )

        # Error flash
        if self.error_flash > 0:
            pygame.draw.rect(screen, (255, 80, 80),
                             (0, 0, self.screen_w, self.screen_h), 4)

        # Win / lose overlays
        if self.won:
            self._draw_ui_text_center(
                screen, self.ui_large, "SOLVED!",
                320, 195, main=self.UI_ORANGE, shadow=self.UI_SHADOW
            )
            self._draw_ui_text_center(
                screen, self.ui_medium,
                "Click or press ESC to return to the hub",
                320, 255
            )
            self._draw_ui_text_center(
                screen, self.ui_medium,
                "Press R to play again",
                320, 285
            )
        elif self.lost:
            self._draw_ui_text_center(
                screen, self.ui_large, "GAME OVER",
                320, 195, main=self.UI_ORANGE, shadow=self.UI_SHADOW
            )
            self._draw_ui_text_center(
                screen, self.ui_medium,
                "Click or press ESC to return to the hub",
                320, 255
            )
            self._draw_ui_text_center(
                screen, self.ui_medium,
                "Press R to retry",
                320, 285
            )

        # Tutorial overlay — drawn last so it sits on top of everything
        if not self._tutorial_shown:
            self._draw_intro(screen)

    # ------------------------------------------------------------------
    def _draw_intro(self, screen):
        # Warm dim overlay
        overlay = pygame.Surface((640, 480), pygame.SRCALPHA)
        overlay.fill((60, 30, 20, 140))
        screen.blit(overlay, (0, 0))

        # Cream page panel with brown border
        panel = pygame.Rect(100, 90, 440, 320)
        pygame.draw.rect(screen, (245, 230, 200), panel, border_radius=18)
        pygame.draw.rect(screen, (150, 90, 60), panel, 4, border_radius=18)

        # Title
        title = self.tut_font.render("HOW TO PLAY", True, (150, 70, 50))
        screen.blit(title, (320 - title.get_width() // 2, 110))

        # Mini 3x3 grid icon
        icon_size = 90
        icon_x = 320 - icon_size // 2
        icon_y = 168
        pygame.draw.rect(screen, (250, 240, 215),
                         (icon_x, icon_y, icon_size, icon_size))
        pygame.draw.rect(screen, (150, 90, 60),
                         (icon_x, icon_y, icon_size, icon_size), 2)
        cell = icon_size // 3
        for i in (1, 2):
            pygame.draw.line(screen, (150, 90, 60),
                             (icon_x + i * cell, icon_y),
                             (icon_x + i * cell, icon_y + icon_size), 2)
            pygame.draw.line(screen, (150, 90, 60),
                             (icon_x, icon_y + i * cell),
                             (icon_x + icon_size, icon_y + i * cell), 2)
        step = cell // 3
        for i in range(1, 9):
            if i % 3 == 0:
                continue
            gx = icon_x + i * step
            gy = icon_y + i * step
            pygame.draw.line(screen, (200, 160, 130),
                             (gx, icon_y), (gx, icon_y + icon_size), 1)
            pygame.draw.line(screen, (200, 160, 130),
                             (icon_x, gy), (icon_x + icon_size, gy), 1)
        marks = [(0, 0), (1, 1), (2, 2), (0, 1), (1, 2), (2, 0)]
        for (mr, mc) in marks:
            cx = icon_x + mr * cell + cell // 2
            cy = icon_y + mc * cell + cell // 2
            pygame.draw.circle(screen, (150, 90, 60), (cx, cy), 3)

        # Body text — three lines, no commas (DaintyCute does not render them)
        lines = [
            "Click a square to select it.",
            "Match every row column and box.",
            "You get three hearts. Wrong guesses cost one.",
        ]
        y = 285
        for line in lines:
            surf = self.tut_body.render(line, True, (90, 55, 40))
            screen.blit(surf, (320 - surf.get_width() // 2, y))
            y += 32

        # "Press any key to begin" pill
        hint_text = "Press any key to begin"
        hint_surf = self.tut_small.render(hint_text, True, (180, 80, 60))
        hint_x = 320 - hint_surf.get_width() // 2
        hint_y = panel.bottom - 32
        pad = 8
        hint_bg = pygame.Rect(
            hint_x - pad, hint_y - pad // 2,
            hint_surf.get_width() + pad * 2,
            hint_surf.get_height() + pad
        )
        pygame.draw.rect(screen, (250, 220, 195), hint_bg, border_radius=8)
        screen.blit(hint_surf, (hint_x, hint_y))
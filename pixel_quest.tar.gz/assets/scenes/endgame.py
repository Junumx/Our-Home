import os
import pygame
from scenes.base_scene import Scene

ASSETS = "assets"
def asset(*parts):
    return os.path.join(ASSETS, *parts)


def load_image(path, size, fallback_color=None, fallback_text=None, font=None):
    if os.path.exists(path):
        img = pygame.image.load(path).convert_alpha()
        return pygame.transform.scale(img, size)
    surf = pygame.Surface(size, pygame.SRCALPHA)
    if fallback_color:
        surf.fill(fallback_color)
    if fallback_text and font:
        t = font.render(fallback_text, True, (255, 255, 255))
        surf.blit(t, (size[0]//2 - t.get_width()//2,
                      size[1]//2 - t.get_height()//2))
    return surf


class EndGameScene(Scene):
    """Final screen with 'The End' image + two buttons.
    Clicking 'Start Over' shows a confirmation dialog first."""

    def __init__(self, manager):
        super().__init__(manager)

        self.title_font  = pygame.font.SysFont("arial", 48, bold=True)
        self.btn_font    = pygame.font.SysFont("arial", 22, bold=True)
        self.dialog_font = pygame.font.SysFont("arial", 26, bold=True)
        self.body_font   = pygame.font.SysFont("arial", 16)
        self.tiny        = pygame.font.SysFont("arial", 12)

        # Full-screen "The End" image (optional art: assets/sprites/the_end.png)
        self.bg = load_image(
            asset("sprites", "the_end.png"),
            (640, 480),
            fallback_color=(15, 12, 30),
            fallback_text="THE END",
            font=self.title_font
        )

        # Main buttons
        self.buttons = [
            {
                "label": "Start Over",
                "action": self._ask_confirm,
                "rect": pygame.Rect(140, 360, 170, 56),
                "hover": False,
            },
            {
                "label": "Back to Title",
                "action": self._back_to_title,
                "rect": pygame.Rect(330, 360, 170, 56),
                "hover": False,
            },
        ]

        # Confirmation dialog state
        self.confirming = False
        self.confirm_buttons = [
            {
                "label": "Yes, erase it",
                "action": self._do_start_over,
                "rect": pygame.Rect(155, 300, 150, 50),
                "hover": False,
            },
            {
                "label": "No, go back",
                "action": self._cancel_confirm,
                "rect": pygame.Rect(335, 300, 150, 50),
                "hover": False,
            },
        ]

        self.t = 0.0

    # ------------------------------------------------------------------
    def handle_event(self, event):
        if self.confirming:
            self._handle_confirm_event(event)
            return

        if event.type == pygame.MOUSEMOTION:
            for b in self.buttons:
                b["hover"] = b["rect"].collidepoint(event.pos)

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for b in self.buttons:
                if b["rect"].collidepoint(event.pos):
                    b["action"]()
                    return

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self._back_to_title()
            elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                self._back_to_title()

    # ------------------------------------------------------------------
    def _handle_confirm_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            for b in self.confirm_buttons:
                b["hover"] = b["rect"].collidepoint(event.pos)

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for b in self.confirm_buttons:
                if b["rect"].collidepoint(event.pos):
                    b["action"]()
                    return

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self._cancel_confirm()
            elif event.key == pygame.K_RETURN:
                self._do_start_over()
            elif event.key == pygame.K_y:
                self._do_start_over()
            elif event.key == pygame.K_n:
                self._cancel_confirm()

    # ------------------------------------------------------------------
    def _ask_confirm(self):
        self.confirming = True
        # Reset hover state on the confirm buttons
        for b in self.confirm_buttons:
            b["hover"] = False

    def _cancel_confirm(self):
        self.confirming = False
        for b in self.confirm_buttons:
            b["hover"] = False

    def _do_start_over(self):
        # Wipe progress and return to the title screen
        self.manager.progress["completed"] = []
        from scenes.start import StartScene
        self.manager.go_to(StartScene(self.manager))

    def _back_to_title(self):
        from scenes.start import StartScene
        self.manager.go_to(StartScene(self.manager))

    # ------------------------------------------------------------------
    def update(self, dt):
        self.t += dt

    # ------------------------------------------------------------------
    def draw(self, screen):
        screen.blit(self.bg, (0, 0))

        # Main buttons
        for b in self.buttons:
            self._draw_button(screen, b, big=True)

        # Footer hint
        if not self.confirming:
            hint = self.tiny.render(
                "Enter / ESC = back to title   •   click a button to choose",
                True, (150, 150, 180)
            )
            screen.blit(hint, (320 - hint.get_width()//2, 455))

        # Confirmation overlay
        if self.confirming:
            self._draw_confirm(screen)

    # ------------------------------------------------------------------
    def _draw_confirm(self, screen):
        # Dim backdrop
        overlay = pygame.Surface((640, 480), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))

        # Panel
        panel = pygame.Rect(120, 150, 400, 230)
        pygame.draw.rect(screen, (35, 30, 55), panel, border_radius=14)
        pygame.draw.rect(screen, (200, 140, 140), panel, 3, border_radius=14)

        title = self.dialog_font.render("Are you sure?", True, (255, 200, 200))
        screen.blit(title, (320 - title.get_width()//2, 180))

        line1 = self.body_font.render(
            "This will erase all your progress", True, (230, 230, 240)
        )
        screen.blit(line1, (320 - line1.get_width()//2, 230))

        line2 = self.body_font.render(
            "and lock every gate again.", True, (230, 230, 240)
        )
        screen.blit(line2, (320 - line2.get_width()//2, 254))

        # Confirm buttons
        for b in self.confirm_buttons:
            self._draw_button(screen, b, big=False)

        hint = self.tiny.render(
            "Y = yes   •   N = no   •   ESC = cancel",
            True, (170, 170, 200)
        )
        screen.blit(hint, (320 - hint.get_width()//2, 365))

    # ------------------------------------------------------------------
    def _draw_button(self, screen, b, big=True):
        rect = b["rect"]
        if b["hover"]:
            bg = (90, 130, 190)
            border = (200, 220, 255)
            txt = (255, 255, 255)
        else:
            bg = (50, 60, 100)
            border = (140, 150, 200)
            txt = (230, 230, 240)

        # Confirm buttons get a red tint on hover for the "yes" option
        if not big:
            if b["label"].startswith("Yes") and b["hover"]:
                bg = (180, 70, 70)
                border = (255, 160, 160)
            elif b["label"].startswith("Yes"):
                bg = (110, 55, 55)
                border = (200, 120, 120)

        pygame.draw.rect(screen, bg, rect, border_radius=10)
        pygame.draw.rect(screen, border, rect, 2, border_radius=10)

        font = self.btn_font if big else self.body_font
        label = font.render(b["label"], True, txt)
        screen.blit(label, (rect.centerx - label.get_width()//2,
                            rect.centery - label.get_height()//2))
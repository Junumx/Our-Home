def __init__(self, manager):
    super().__init__(manager)
    self.screen_w, self.screen_h = 640, 480

    # --- Fonts ---
    self.font       = load_font("FatPix-SVG.otf", 28)
    self.small_font = load_font("FatPix-SVG.otf", 14)
    self.tiny_font  = load_font("FatPix-SVG.otf", 12)

    # --- Background ---
    self.bg = load_image(
        asset("sprites", "hub_bg.png"),
        (self.screen_w, self.screen_h),
        fallback_color=(255, 210, 200)
    )

    # --- Sprite cache ---
    self._gate_cache = {}

    # --- Load masks (raw) ---
    self.masks = {}
    for key in list(GATE_ORDER) + ["end"]:
        path = asset("sprites", f"{key}_mask.png")
        if os.path.exists(path):
            img = pygame.image.load(path).convert_alpha()
            img = pygame.transform.scale(
                img, (self.screen_w, self.screen_h)
            )
            self.masks[key] = img
        else:
            self.masks[key] = None

    # --- Gates derived from mask bounding boxes ---
    self.gates = []
    for key in GATE_ORDER:
        rect = self._mask_rect(key)
        if rect is None:
            rect = pygame.Rect(0, 0, 60, 60)
        self.gates.append(Gate(rect.x, rect.y, key,
                               (rect.width, rect.height)))

    end_rect = self._mask_rect("end")
    if end_rect is None:
        end_rect = pygame.Rect(0, 0, 60, 60)
    self.end_gate = Gate(end_rect.x, end_rect.y, "end",
                         (end_rect.width, end_rect.height))

    # --- Back button (pixel wooden V) ---
    self.back_img = load_image(
        asset("sprites", "back_arrow.png"),
        (80, 32),
        fallback_color=None
    )
    self.back_has_sprite = os.path.exists(
        asset("sprites", "back_arrow.png")
    )
    self.back_rect = pygame.Rect(0, 0, 80, 32)
    self.back_rect.center = (self.screen_w // 2, 448)
    self.back_hover = False

    if self.back_has_sprite:
        self.back_img_rotated = pygame.transform.rotate(self.back_img, -6)
    else:
        self.back_img_rotated = None

    # --- Checkmark (drawn over completed games) ---
    self.check_img = load_image(
        asset("sprites", "checkmark.png"),
        (48, 48),
        fallback_color=None
    )
    self.check_has_sprite = os.path.exists(
        asset("sprites", "checkmark.png")
    )

    # --- Lock (drawn over the end door when it's still locked) ---
    self.lock_img = load_image(
        asset("sprites", "lock.png"),
        (52, 52),
        fallback_color=None
    )
    self.lock_has_sprite = os.path.exists(
        asset("sprites", "lock.png")
    )

    # --- Animation timer ---
    self.t = 0.0
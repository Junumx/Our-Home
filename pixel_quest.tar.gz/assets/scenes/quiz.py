import os
import pygame
from scenes.base_scene import Scene

ASSETS = "assets"
def asset(*parts):
    return os.path.join(ASSETS, *parts)


def load_image(path, size, fallback_color=None):
    if os.path.exists(path):
        img = pygame.image.load(path).convert_alpha()
        return pygame.transform.scale(img, size)
    surf = pygame.Surface(size, pygame.SRCALPHA)
    if fallback_color:
        surf.fill(fallback_color)
    return surf


def load_font(name, size):
    path = os.path.join(ASSETS, "fonts", name)
    if os.path.exists(path):
        return pygame.font.Font(path, size)
    if name.endswith(".otf"):
        alt = name[:-4] + ".ttf"
    elif name.endswith(".ttf"):
        alt = name[:-4] + ".otf"
    else:
        alt = None
    if alt:
        alt_path = os.path.join(ASSETS, "fonts", alt)
        if os.path.exists(alt_path):
            return pygame.font.Font(alt_path, size)
    return pygame.font.SysFont("arial", size, bold=True)


FONT_FILE     = "FatPix-SVG.otf"
TUTORIAL_FONT = "DaintyCute.otf"

UI_MAIN   = (255, 215, 140)
UI_SHADOW = (110, 55, 30)


# ==================================================================
# DIALOGUE LINES
# ==================================================================
INTRO_DIALOGUE = [
    "Hey Pooks :)",
    "Before you go into the last room for the surprise, \nyou have to complete this quiz. Good luck :P",
]

BETWEEN_DIALOGUE = [
    "Hooray, you got it!",
    "Amen amen :)",
    "Hehe good job :D \n(I just wanted to show the hamster :P)",
    "Yurr, one final question :)",
]

OUTRO_DIALOGUE = [
    "Yayy you did it! :D",
    "You can enter the room now :P",
]

# Fallback wrong lines (used only if a question has no custom wrong_lines)
DEFAULT_WRONG = [
    "Noo you got it wrong :(",
]

# Hamster image size on-screen (native 132x96, displayed at 2x)
HAMSTER_SIZE = (264, 192)


# ==================================================================
# EDIT YOUR QUESTIONS HERE
# ==================================================================
QUESTIONS = [
    {
        "prompt": "What date is our anniversary on?",
        "answers": ["October 18th", "October 16th",
                    "October 19th", "October 17th"],
        "correct": 0,
        "wrong_lines": [
            "Noo you got it wrong :(",
        ],
    },
    {
        "prompt": "What bouquet of artificial flowers did I first give you?",
        "answers": ["Jellycat Flowers", "Pipe Cleaner Flowers",
                    "Lego Flowers", "Ribbon Rose Flowers"],
        "correct": 1,
        "wrong_lines": [
            "Sorry, thats wrong :(",
        ],
    },
    {
        # Both answers are always wrong on first pick.
        # The remaining answer (second pick) is always right.
        "prompt": "What number am I thinking of?",
        "answers": ["Two Hundred Seventy One", "Five"],
        "either_wrong": True,
        "wrong_lines": [
            ":P",
        ],
    },
    {
        "prompt": "I couldn't never not refuse to not stop not loving you, couldn't I?",
        "answers": ["Yes", "No"],
        "correct": 0,
        "wrong_lines": [
            "Whoopsies, read it again :P",
        ],
    },
    {
        "prompt": "How much do I love you?",
        "answers": ["n0t", "INFINITELY + INFINITY^INFINITY*INFINITY",
                    "poopie no", "i farted so no"],
        "correct": 1,
        "wrong_lines": [
            ":(",
        ],
    },
]


class QuizScene(Scene):
    KEY = "quiz"

    LIGHT_DURATION = 1.2

    QUIZMASTER_SIZE = (171, 279)
    QUIZMASTER_OFFSET_Y = -30

    BOX_HEIGHT = 130

    def __init__(self, manager):
        super().__init__(manager)
        self.screen_w, self.screen_h = 640, 480

        self.ui_font    = load_font(FONT_FILE, 18)
        self.ui_small   = load_font(FONT_FILE, 14)
        self.ui_tiny    = load_font(FONT_FILE, 11)
        self.ui_large   = load_font(FONT_FILE, 30)

        self.tut_font   = load_font(TUTORIAL_FONT, 22)
        self.tut_answer = load_font(TUTORIAL_FONT, 18)

        self.bg = load_image(
            asset("sprites", "door_bg.png"),
            (self.screen_w, self.screen_h),
            fallback_color=(220, 160, 140)
        )

        self.door_open_img = load_image(
            asset("sprites", "door_open.png"),
            (self.screen_w, self.screen_h),
            fallback_color=None
        )
        self.door_open_has_sprite = os.path.exists(
            asset("sprites", "door_open.png")
        )

        self.quizmaster = load_image(
            asset("sprites", "quizmaster.png"),
            self.QUIZMASTER_SIZE,
            fallback_color=None
        )
        self.quizmaster_has_sprite = os.path.exists(
            asset("sprites", "quizmaster.png")
        )

        self.hamster = load_image(
            asset("sprites", "hamster.png"),
            HAMSTER_SIZE,
            fallback_color=(220, 180, 140)
        )
        self.hamster_has_sprite = os.path.exists(
            asset("sprites", "hamster.png")
        )

        self.reset()

    # ------------------------------------------------------------------
    def reset(self):
        self.index = 0
        self.crossed_out = [set() for _ in QUESTIONS]
        self.attempts_on_current = {}
        # Phases: intro / asking / wrong / between / outro / ending
        self.state = "intro"
        self.dialogue_line = 0
        self.wrong_line = ""
        self.timer = 0.0
        self.hover_index = -1
        self.answer_rects = []
        self.light_t = 0.0

    # ------------------------------------------------------------------
    def _admin_combo(self):
        keys = pygame.key.get_pressed()
        return (keys[pygame.K_LCTRL] and
                keys[pygame.K_LSHIFT] and
                keys[pygame.K_k])

    def _quizmaster_pos(self):
        qw, qh = self.QUIZMASTER_SIZE
        qx = 320 - qw // 2
        qy = 240 - qh // 2 + self.QUIZMASTER_OFFSET_Y
        return (qx, qy)

    # ------------------------------------------------------------------
    def _advance_dialogue(self):
        if self.state == "intro":
            self.dialogue_line += 1
            if self.dialogue_line >= len(INTRO_DIALOGUE):
                self.state = "asking"
                self.dialogue_line = 0

        elif self.state == "between":
            self.state = "asking"
            self.dialogue_line = 0

        elif self.state == "wrong":
            self.state = "asking"
            self.wrong_line = ""

        elif self.state == "outro":
            self.dialogue_line += 1
            if self.dialogue_line >= len(OUTRO_DIALOGUE):
                self.state = "ending"
                self.light_t = 0.0
                self.dialogue_line = 0

    # ------------------------------------------------------------------
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self._leave()
                return

            if event.key == pygame.K_k and self._admin_combo():
                self._complete()
                self.state = "ending"
                self.light_t = 0.0
                return

            if self.state in ("intro", "between", "wrong", "outro"):
                self._advance_dialogue()
                return

            if self.state == "asking" and self.index < len(QUESTIONS):
                q = QUESTIONS[self.index]
                num_keys = [pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4,
                            pygame.K_5, pygame.K_6, pygame.K_7, pygame.K_8,
                            pygame.K_9]
                for i, k in enumerate(num_keys):
                    if event.key == k and i < len(q["answers"]):
                        if i not in self.crossed_out[self.index]:
                            self._answer(i)
                        break

        elif event.type == pygame.MOUSEMOTION:
            self.hover_index = -1
            if self.state == "asking":
                for i, r in enumerate(self.answer_rects):
                    if (r.collidepoint(event.pos)
                            and i not in self.crossed_out[self.index]):
                        self.hover_index = i
                        break

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.state in ("intro", "between", "wrong", "outro"):
                self._advance_dialogue()
                return

            if self.state == "asking":
                for i, r in enumerate(self.answer_rects):
                    if (r.collidepoint(event.pos)
                            and i not in self.crossed_out[self.index]):
                        self._answer(i)
                        break

    # ------------------------------------------------------------------
    def _wrong_line_for(self, q, attempt_index):
        """Pick a wrong line for this question, based on attempt number."""
        lines = q.get("wrong_lines", DEFAULT_WRONG)
        if attempt_index < len(lines):
            return lines[attempt_index]
        return lines[attempt_index % len(lines)]

    # ------------------------------------------------------------------
    def _answer(self, i):
        if self.index >= len(QUESTIONS):
            return
        q = QUESTIONS[self.index]

        # ----- Tricky "either_wrong" questions -----
        # First click (either option): always wrong, cross it out.
        # Second click (only remaining option): always right, advance.
        if q.get("either_wrong"):
            attempts = self.attempts_on_current.get(self.index, 0)

            if attempts == 0:
                # First wrong attempt
                self.attempts_on_current[self.index] = 1
                self.crossed_out[self.index].add(i)
                self.state = "wrong"
                self.wrong_line = self._wrong_line_for(q, 0)
                self.hover_index = -1
                return
            else:
                # Second attempt — always right
                self.attempts_on_current[self.index] = 2
                self._advance_question()
                return

        # ----- Normal questions -----
        if i == q["correct"]:
            self._advance_question()
        else:
            self.crossed_out[self.index].add(i)
            self.state = "wrong"
            self.wrong_line = self._wrong_line_for(q, 0)
            self.hover_index = -1

    def _advance_question(self):
        self.index += 1
        self.hover_index = -1

        if self.index >= len(QUESTIONS):
            self._complete()
            self.state = "outro"
            self.dialogue_line = 0
        else:
            if self.index - 1 < len(BETWEEN_DIALOGUE):
                self.state = "between"
                self.dialogue_line = 0
            else:
                self.state = "asking"

    # ------------------------------------------------------------------
    def update(self, dt):
        self.timer += dt

        if self.state == "ending":
            self.light_t += dt
            if self.light_t >= self.LIGHT_DURATION:
                from scenes.end import EndScene
                self.manager.go_to(lambda: EndScene(self.manager))

    # ------------------------------------------------------------------
    def _complete(self):
        if self.KEY not in self.manager.progress["completed"]:
            self.manager.progress["completed"].append(self.KEY)

    def _leave(self):
        from scenes.hub import HubScene
        self.manager.go_to(lambda: HubScene(self.manager))

    # ------------------------------------------------------------------
    def draw(self, screen):
        if self.state == "ending":
            screen.blit(self.bg, (0, 0))

            if self.door_open_has_sprite:
                p = min(self.light_t / (self.LIGHT_DURATION * 0.5), 1.0)
                alpha = int(255 * p)
                overlay = self.door_open_img.copy()
                overlay.set_alpha(alpha)
                screen.blit(overlay, (0, 0))

            p = min(self.light_t / self.LIGHT_DURATION, 1.0)
            eased = p * p
            radius = int(eased * 900)
            if radius > 0:
                for r in range(radius, max(0, radius - 30), -30):
                    alpha = max(0, 255 - (radius - r) * 4)
                    if alpha <= 0:
                        continue
                    glow = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
                    pygame.draw.circle(glow, (255, 240, 200, alpha),
                                       (r, r), r)
                    screen.blit(glow, (320 - r, 240 - r),
                                special_flags=pygame.BLEND_RGBA_ADD)

            if p > 0.7:
                fade_alpha = int(255 * (p - 0.7) / 0.3)
                fade_alpha = max(0, min(255, fade_alpha))
                white = pygame.Surface((640, 480))
                white.fill((255, 250, 240))
                white.set_alpha(fade_alpha)
                screen.blit(white, (0, 0))
            return

        # --- Normal view ---
        screen.blit(self.bg, (0, 0))

        if self.quizmaster_has_sprite and self.state != "wrong":
            screen.blit(self.quizmaster, self._quizmaster_pos())

        if self.state == "wrong":
            hamster_rect = self.hamster.get_rect(center=(320, 200))
            screen.blit(self.hamster, hamster_rect.topleft)

        box = pygame.Rect(20, self.screen_h - self.BOX_HEIGHT - 16,
                          self.screen_w - 40, self.BOX_HEIGHT)

        shadow = pygame.Surface((box.width + 12, box.height + 12),
                                pygame.SRCALPHA)
        shadow.fill((30, 15, 10, 90))
        screen.blit(shadow, (box.x + 6, box.y + 8))

        # Opaque cream panel — drawn rounded so corners match the border
        pygame.draw.rect(screen, (245, 230, 200), box, border_radius=12)
        pygame.draw.rect(screen, (150, 90, 60), box, 4, border_radius=12)

        if self.state == "intro":
            self._draw_dialogue_phase(screen, box, INTRO_DIALOGUE,
                                      self.dialogue_line)
        elif self.state == "between":
            self._draw_dialogue_phase(
                screen, box, [BETWEEN_DIALOGUE[self.index - 1]], 0
            )
        elif self.state == "wrong":
            self._draw_dialogue_phase(
                screen, box, [self.wrong_line], 0, speaker="Hmm?"
            )
        elif self.state == "outro":
            self._draw_dialogue_phase(screen, box, OUTRO_DIALOGUE,
                                      self.dialogue_line)
        else:
            self._draw_quiz_phase(screen, box)

    # ------------------------------------------------------------------
    def _wrap_text(self, text, font, max_width):
        result = []
        for paragraph in text.split("\n"):
            if paragraph == "":
                result.append("")
                continue
            words = paragraph.split(" ")
            current = ""
            for w in words:
                trial = (current + " " + w).strip()
                if font.size(trial)[0] <= max_width:
                    current = trial
                else:
                    if current:
                        result.append(current)
                    current = w
            if current:
                result.append(current)
        return result

    def _draw_dialogue_phase(self, screen, box, lines, line_index,
                             speaker="Jonam"):
        speaker_surf = self.ui_small.render(speaker, False, (150, 70, 50))
        screen.blit(speaker_surf, (box.left + 20, box.top + 14))

        max_text_width = box.width - 40
        wrapped = self._wrap_text(lines[line_index], self.tut_font,
                                  max_text_width)

        line_height = self.tut_font.get_linesize() + 2
        total_height = len(wrapped) * line_height
        start_y = box.top + 42 + max(0, (60 - total_height) // 2)

        for i, line in enumerate(wrapped):
            if line == "":
                continue
            text_surf = self.tut_font.render(line, True, (90, 55, 40))
            screen.blit(text_surf,
                        (box.centerx - text_surf.get_width() // 2,
                         start_y + i * line_height))

        pulse = 0.5 + 0.5 * pygame.math.Vector2(1, 0).rotate(self.timer * 200).x
        shade = int(150 + 80 * pulse)
        hint = self.ui_tiny.render(
            "Click or press any key to continue",
            False, (shade, shade - 30, shade - 60)
        )
        screen.blit(hint, (box.centerx - hint.get_width() // 2,
                           box.bottom - 24))

        ax = box.right - 30
        ay = box.bottom - 22
        pygame.draw.polygon(screen, (150, 90, 60), [
            (ax, ay - 4),
            (ax + 8, ay - 4),
            (ax + 4, ay + 4),
        ])

    # ------------------------------------------------------------------
    def _draw_quiz_phase(self, screen, box):
        for i in range(len(QUESTIONS)):
            dx = 320 - (len(QUESTIONS) - 1) * 10 + i * 20
            dy = box.top + 12
            color = (120, 200, 120) if i < self.index else (200, 170, 130)
            pygame.draw.circle(screen, color, (dx, dy), 4)

        if self.index >= len(QUESTIONS):
            return

        q = QUESTIONS[self.index]
        prompt = self.tut_font.render(q["prompt"], True, (150, 70, 50))
        screen.blit(prompt,
                    (box.centerx - prompt.get_width() // 2,
                     box.top + 24))

        crossed = self.crossed_out[self.index]

        self.answer_rects = []
        cols = 2
        btn_w = (box.width - 40) // cols - 8
        btn_h = 28
        grid_x = box.left + 16
        grid_y = box.top + 56

        for i, ans in enumerate(q["answers"]):
            row = i // cols
            col = i % cols
            rx = grid_x + col * (btn_w + 16)
            ry = grid_y + row * (btn_h + 6)
            rect = pygame.Rect(rx, ry, btn_w, btn_h)
            self.answer_rects.append(rect)

            is_crossed = i in crossed
            is_hovered = (i == self.hover_index and not is_crossed)

            if is_crossed:
                bg_color = (225, 205, 190)
                border = (170, 140, 130)
                txt_color = (140, 120, 110)
            elif is_hovered:
                bg_color = (255, 220, 170)
                border = (200, 130, 80)
                txt_color = (120, 60, 40)
            else:
                bg_color = (250, 235, 210)
                border = (170, 120, 90)
                txt_color = (90, 55, 40)

            pygame.draw.rect(screen, bg_color, rect, border_radius=6)
            pygame.draw.rect(screen, border, rect, 2, border_radius=6)

            label = f"{i+1}. {ans}"
            surf = self.tut_answer.render(label, True, txt_color)
            screen.blit(surf, (rect.x + 10,
                               rect.centery - surf.get_height() // 2))

            if is_crossed:
                pygame.draw.line(screen, (200, 80, 80),
                                 (rect.left + 6, rect.top + 6),
                                 (rect.right - 6, rect.bottom - 6), 3)
                pygame.draw.line(screen, (200, 80, 80),
                                 (rect.right - 6, rect.top + 6),
                                 (rect.left + 6, rect.bottom - 6), 3)
import os
import random
import pygame
from scenes.base_scene import Scene

ASSETS = "assets"
def asset(*parts):
    return os.path.join(ASSETS, *parts)


def load_image(path, size, fallback_color=None):
    if os.path.exists(path):
        img = pygame.image.load(path).convert_alpha()
        return pygame.transform.scale(img, size)
    surf = pygame.Surface(size, pygame.SRCALPHA)
    if fallback_color:
        surf.fill(fallback_color)
    return surf


def load_font(name, size):
    path = os.path.join(ASSETS, "fonts", name)
    if os.path.exists(path):
        return pygame.font.Font(path, size)
    if name.endswith(".otf"):
        alt = name[:-4] + ".ttf"
    elif name.endswith(".ttf"):
        alt = name[:-4] + ".otf"
    else:
        alt = None
    if alt:
        alt_path = os.path.join(ASSETS, "fonts", alt)
        if os.path.exists(alt_path):
            return pygame.font.Font(alt_path, size)
    return pygame.font.SysFont("arial", size, bold=True)


FONT_FILE     = "FatPix-SVG.otf"
TUTORIAL_FONT = "DaintyCute.otf"

UI_MAIN   = (255, 215, 140)
UI_SHADOW = (110, 55, 30)
UI_ORANGE = (255, 155, 120)


CARD_FILES = [
    "memory_1.png",
    "memory_2.png",
    "memory_3.png",
    "memory_4.png",
    "memory_5.png",
    "memory_6.png",
    "memory_7.png",
    "memory_8.png",
    "memory_9.png",
    "memory_10.png",
]

CARD_FALLBACK_COLORS = [
    (220,  80,  80),
    ( 80, 180, 220),
    (240, 200,  80),
    (140, 220, 120),
    (200, 120, 220),
    (240, 140,  60),
    (120, 140, 240),
    ( 90, 220, 200),
    (230, 110, 160),
    (170, 200,  90),
]


class MemoryScene(Scene):
    KEY = "memory"

    COLS = 5
    ROWS = 4
    TILE = 63
    CARD_SIZE = 59
    ORIGIN = (167, 77)

    # Flipping animation
    FLIP_TIME = 0.35      # seconds per full flip (half in, half out)
    MISMATCH_PAUSE = 0.7  # seconds a mismatched pair stays revealed before flipping back

    def __init__(self, manager):
        super().__init__(manager)
        self.screen_w, self.screen_h = 640, 480

        self.ui_font   = load_font(FONT_FILE, 24)
        self.ui_medium = load_font(FONT_FILE, 20)
        self.ui_large  = load_font(FONT_FILE, 34)

        self.tut_font  = load_font(TUTORIAL_FONT, 26)
        self.tut_body  = load_font(TUTORIAL_FONT, 20)
        self.tut_small = load_font(TUTORIAL_FONT, 18)

        self.bg = load_image(
            asset("sprites", "memory_bg.png"),
            (self.screen_w, self.screen_h),
            fallback_color=(230, 180, 130)
        )

        self.card_back = load_image(
            asset("sprites", "memory_card_back.png"),
            (self.CARD_SIZE, self.CARD_SIZE),
            fallback_color=(245, 235, 215)
        )
        self.card_back_has_sprite = os.path.exists(
            asset("sprites", "memory_card_back.png")
        )

        self.card_faces = []
        for i, fname in enumerate(CARD_FILES):
            path = asset("sprites", fname)
            if os.path.exists(path):
                img = pygame.image.load(path).convert_alpha()
                img = pygame.transform.scale(img, (self.CARD_SIZE, self.CARD_SIZE))
                self.card_faces.append(img)
            else:
                color = CARD_FALLBACK_COLORS[i % len(CARD_FALLBACK_COLORS)]
                surf = pygame.Surface((self.CARD_SIZE, self.CARD_SIZE),
                                      pygame.SRCALPHA)
                surf.fill(color)
                self.card_faces.append(surf)

        self.card_offset = (self.TILE - self.CARD_SIZE) // 2

        self._tutorial_shown = False
        self.reset()

    # ------------------------------------------------------------------
    def reset(self):
        indices = list(range(len(self.card_faces))) * 2
        random.shuffle(indices)
        self.deck = indices

        self.flipped = []           # indices currently flipped face-up
        self.matched = set()        # indices permanently matched
        self.mismatch_timer = 0.0   # time before mismatched pair flips back
        self.moves = 0
        self.won = False

        # Per-card flip animation state
        # anim[i] = {"t": time_elapsed, "to": "face" or "back"}
        # If no entry, card is showing its "settled" face (back if not
        # matched/flipped, face if matched/flipped).
        self.flip_anim = {}

        # Track what each card currently DISPLAYS (face or back)
        # after accounting for animations. This is what we use to decide
        # what to draw when the animation isn't running.
        self.visual = ["back"] * (self.ROWS * self.COLS)

    # ------------------------------------------------------------------
    def _admin_combo(self):
        keys = pygame.key.get_pressed()
        return (keys[pygame.K_LCTRL] and
                keys[pygame.K_LSHIFT] and
                keys[pygame.K_k])

    # ------------------------------------------------------------------
    def handle_event(self, event):
        if not self._tutorial_shown:
            if (event.type == pygame.KEYDOWN or
                    (event.type == pygame.MOUSEBUTTONDOWN
                     and event.button == 1)):
                self._tutorial_shown = True
            return

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_k and self._admin_combo():
                self._complete()
                self.won = True
                return
            if event.key == pygame.K_ESCAPE:
                self._leave()
            elif event.key == pygame.K_r:
                self.reset()

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.won:
                self._leave()
                return
            if self.lock_timer > 0:
                return
            idx = self._tile_at(event.pos)
            if idx is None or idx in self.matched or idx in self.flipped:
                return
            self.flipped.append(idx)
            if len(self.flipped) == 2:
                self.moves += 1
                a, b = self.flipped
                if self.deck[a] == self.deck[b]:
                    self.matched.update(self.flipped)
                    self.flipped = []
                    if len(self.matched) == len(self.deck):
                        self.won = True
                        self._complete()
                else:
                    self.lock_timer = 0.75

    def _start_flip(self, idx, target):
        """Begin a flip animation for card `idx` toward `target` ('face' or 'back')."""
        self.flip_anim[idx] = {"t": 0.0, "to": target}

    def _tile_at(self, pos):
        ox, oy = self.ORIGIN
        x, y = pos
        board_w = self.COLS * self.TILE
        board_h = self.ROWS * self.TILE
        if not (ox <= x < ox + board_w and oy <= y < oy + board_h):
            return None
        c = (x - ox) // self.TILE
        r = (y - oy) // self.TILE
        return r * self.COLS + c

    # ------------------------------------------------------------------
    def update(self, dt):
        if not self._tutorial_shown:
            return

        # Advance all flip animations
        for idx in list(self.flip_anim.keys()):
            anim = self.flip_anim[idx]
            anim["t"] += dt
            if anim["t"] >= self.FLIP_TIME:
                # Animation complete — settle the card on the target face
                self.visual[idx] = anim["to"]
                del self.flip_anim[idx]

        # Advance the mismatch timer
        if self.mismatch_timer > 0:
            self.mismatch_timer -= dt
            if self.mismatch_timer <= 0:
                # Flip the mismatched pair back to face-down
                for idx in self.flipped:
                    self._start_flip(idx, "back")
                self.flipped = []

    # ------------------------------------------------------------------
    def _complete(self):
        if self.KEY not in self.manager.progress["completed"]:
            self.manager.progress["completed"].append(self.KEY)

    def _leave(self):
        from scenes.hub import HubScene
        self.manager.go_to(lambda: HubScene(self.manager))

    # ------------------------------------------------------------------
    def _draw_ui_text(self, screen, font, text, x, y,
                      main=UI_MAIN, shadow=UI_SHADOW):
        shadow_surf = font.render(text, False, shadow)
        main_surf   = font.render(text, False, main)
        screen.blit(shadow_surf, (x + 2, y + 2))
        screen.blit(main_surf,   (x, y))
        return main_surf.get_width()

    def _draw_ui_text_center(self, screen, font, text, cx, y,
                             main=UI_MAIN, shadow=UI_SHADOW):
        main_surf = font.render(text, False, main)
        shadow_surf = font.render(text, False, shadow)
        x = cx - main_surf.get_width() // 2
        screen.blit(shadow_surf, (x + 2, y + 2))
        screen.blit(main_surf,   (x,     y))

    # ------------------------------------------------------------------
    def _draw_flipping_card(self, screen, surface, x, y, progress):
        """
        Draw a card squashed horizontally to simulate a flip.
        progress: 0.0 (full width) -> 0.5 (zero width) -> 1.0 (full width).
        Surface is drawn centered at (x + CARD_SIZE/2, y + CARD_SIZE/2).
        """
        # Width scale: shrink to 0 at the midpoint, back to 1 at the end
        if progress <= 0.5:
            w_scale = 1.0 - (progress / 0.5)   # 1 -> 0
        else:
            w_scale = (progress - 0.5) / 0.5   # 0 -> 1

        w = max(1, int(self.CARD_SIZE * w_scale))
        h = self.CARD_SIZE
        scaled = pygame.transform.scale(surface, (w, h))
        scaled_rect = scaled.get_rect(center=(x + self.CARD_SIZE // 2,
                                              y + self.CARD_SIZE // 2))
        screen.blit(scaled, scaled_rect.topleft)

    # ------------------------------------------------------------------
    def draw(self, screen):
        screen.blit(self.bg, (0, 0))

        # Title + counter with hyphen
        title_w = self._draw_ui_text(screen, self.ui_font, "Memory", 20, 16)
        dash_x = 20 + title_w + 12
        dash_w = self._draw_ui_text(screen, self.ui_font, "-", dash_x, 16)
        counter_x = dash_x + dash_w + 12
        self._draw_ui_text(screen, self.ui_font, f"{self.moves}", counter_x, 16)

        # Cards
        ox, oy = self.ORIGIN
        for i in range(self.ROWS * self.COLS):
            r, c = divmod(i, self.COLS)
            cx = ox + c * self.TILE + self.card_offset
            cy = oy + r * self.TILE + self.card_offset

            if i in self.flip_anim:
                # Animate
                anim = self.flip_anim[i]
                progress = min(anim["t"] / self.FLIP_TIME, 1.0)

                # Determine what to show at this moment:
                # Before midpoint, show the CURRENT face (the one we're leaving).
                # After midpoint, show the NEW face.
                current_face = self.visual[i]        # what the card was showing
                new_face = anim["to"]

                if progress < 0.5:
                    surf = self._surface_for(i, current_face)
                else:
                    surf = self._surface_for(i, new_face)

                self._draw_flipping_card(screen, surf, cx, cy, progress)
            else:
                # Steady state — draw the settled face
                face = self.visual[i]
                surf = self._surface_for(i, face)
                screen.blit(surf, (cx, cy))

        # Tutorial overlay
        if not self._tutorial_shown:
            self._draw_intro(screen)
            return

        # Win screen
        if self.won:
            self._draw_ui_text_center(
                screen, self.ui_large, "SOLVED!",
                320, 195, main=UI_ORANGE, shadow=UI_SHADOW
            )
            self._draw_ui_text_center(
                screen, self.ui_medium,
                "Click or press ESC to return to the hub",
                320, 255
            )
            self._draw_ui_text_center(
                screen, self.ui_medium,
                "Press R to replay",
                320, 285
            )

    def _surface_for(self, idx, face):
        """Return the sprite to draw for a card showing `face` ('face' or 'back')."""
        if face == "face":
            return self.card_faces[self.deck[idx]]
        else:
            if self.card_back_has_sprite:
                return self.card_back
            else:
                # Fallback: cream card
                surf = pygame.Surface((self.CARD_SIZE, self.CARD_SIZE),
                                      pygame.SRCALPHA)
                surf.fill((245, 235, 215))
                pygame.draw.rect(surf, (140, 100, 70), surf.get_rect(), 1,
                                 border_radius=4)
                return surf

    # ------------------------------------------------------------------
    def _draw_intro(self, screen):
        overlay = pygame.Surface((640, 480), pygame.SRCALPHA)
        overlay.fill((60, 30, 20, 140))
        screen.blit(overlay, (0, 0))

        panel = pygame.Rect(100, 90, 440, 320)
        pygame.draw.rect(screen, (245, 230, 200), panel, border_radius=18)
        pygame.draw.rect(screen, (150, 90, 60), panel, 4, border_radius=18)

        title = self.tut_font.render("HOW TO PLAY", True, (150, 70, 50))
        screen.blit(title, (320 - title.get_width() // 2, 110))

        # Mini memory icon — properly centered
        icon_cx, icon_cy = 320, 195
        card_size = 22
        gap = 6
        cluster = 2 * card_size + gap
        start_x = icon_cx - cluster // 2
        start_y = icon_cy - cluster // 2

        card_offsets = [
            (0, 0),
            (card_size + gap, 0),
            (0, card_size + gap),
            (card_size + gap, card_size + gap),
        ]
        flipped_indices = {0, 3}

        for i, (dx, dy) in enumerate(card_offsets):
            r = pygame.Rect(start_x + dx, start_y + dy, card_size, card_size)
            if i in flipped_indices:
                pygame.draw.rect(screen, (200, 140, 90), r, border_radius=3)
            else:
                pygame.draw.rect(screen, (245, 235, 215), r, border_radius=3)
            pygame.draw.rect(screen, (140, 100, 70), r, 2, border_radius=3)

        lines = [
            "Click a card to flip it.",
            "Match two of the same to clear them.",
            "Find all ten pairs to win.",
        ]
        y = 265
        for line in lines:
            surf = self.tut_body.render(line, True, (90, 55, 40))
            screen.blit(surf, (320 - surf.get_width() // 2, y))
            y += 30

        hint_text = "Press any key to begin"
        hint_surf = self.tut_small.render(hint_text, True, (180, 80, 60))
        hint_x = 320 - hint_surf.get_width() // 2
        hint_y = panel.bottom - 40
        pad = 8
        hint_bg = pygame.Rect(
            hint_x - pad, hint_y - pad // 2,
            hint_surf.get_width() + pad * 2,
            hint_surf.get_height() + pad
        )
        pygame.draw.rect(screen, (250, 220, 195), hint_bg, border_radius=8)
        screen.blit(hint_surf, (hint_x, hint_y))